# Figure 4C — Check short ligand contacts

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 4C
- Claim: The 7XBN rank 3 pose contains four protein-ligand contacts below 2.2 angstrom.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/case03_real_validity_failure_7xbn_rank3.png`
- Evidence summary: Review the supplied atom-pair table and its coordinates against the highlighted contact view.: The supplied table lists four contacts at 1.762293, 1.785112, 1.825922 and 1.896798 angstrom. The separate render metadata records five validity flags.
- Visual meanings: colored on `pocket_surface`: needs review; transparency changed on `pocket_surface`: needs review
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Review the supplied atom-pair table and its coordinates against the highlighted contact view.: The supplied table lists four contacts at 1.762293, 1.785112, 1.825922 and 1.896798 angstrom. The separate render metadata records five validity flags.

## Visual meanings

- colored on `pocket_surface`: needs review
- transparency changed on `pocket_surface`: needs review
- colored on `pocket and elem C`: needs review
- transparency changed on `pocket`: needs review
- colored on `clash_region and receptor and elem C`: needs review
- transparency changed on `clash_region and receptor`: needs review
- transparency changed on `failed_pose`: needs review
- colored on `(failed_pose) and elem C`: needs review
- colored on `(failed_pose) and elem O`: needs review
- colored on `(failed_pose) and elem N`: needs review
- colored on `(failed_pose) and elem S`: needs review
- colored on `(failed_pose) and elem CL`: needs review
- colored on `close_contact_proxy`: needs review
- colored on `close_ligand`: needs review

## Open items and limits

- Recommended: A ligand-binding claim needs stable ligand and binding-site/residue identities linked to its evidence.
- Additional review items: 20; see `human_review_required` in `validation_report.json`.
- Scope: Imported scene instructions preserve visual context. Viewer loading, selections, and rendered output require a replay check.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: 2 present / 1 present
- Structure/map files: 2 present
- Evidence entries: 2 recorded
- Dedicated evidence/validation files: 2 present
- `Figure 4C`: The 7XBN rank 3 pose contains four protein-ligand contacts below 2.2 angstrom.
  Renders: `renders/case03_real_validity_failure_7xbn_rank3.png` (Rendered panel)
  Native files: `native/case03_real_validity_failure_7xbn_rank3.pml` (PyMOL scene)
  Supporting files: `data/case03_real_validity_failure_7xbn_rank3.png.metadata.json` (Contact table), `evidence/case03_selected_close_contacts.csv` (Contact table), `native/data/docking/case03_7xbn_receptor/protein.pdbqt` (Structure file), `native/data/docking/case03_7xbn_pose/rank3_score0.63.sdf` (Structure file)

## Claims

### Figure 4C

- Text: The 7XBN rank 3 pose contains four protein-ligand contacts below 2.2 angstrom.
- Type: ligand_binding_pose
- Figure/panel: Figure 4C
- Linked scenes: 1
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- measurement
  Claim link: claim link pending
  How it was checked: PyMOL distance command
  Source files: `native/case03_real_validity_failure_7xbn_rank3.pml` (PyMOL scene)
  Observation: Distance/measurement intent observed in PyMOL script; not classified as a hydrogen bond or contact.
- contact table
  Claim link: claim:gui:58a1c981734f
  How it was checked: Review the supplied atom-pair table and its coordinates against the highlighted contact view.
  Source files: `data/case03_real_validity_failure_7xbn_rank3.png.metadata.json` (Contact table), `evidence/case03_selected_close_contacts.csv` (Contact table), `native/data/docking/case03_7xbn_receptor/protein.pdbqt` (Structure file), `native/data/docking/case03_7xbn_pose/rank3_score0.63.sdf` (Structure file)
  Observation: The supplied table lists four contacts at 1.762293, 1.785112, 1.825922 and 1.896798 angstrom. The separate render metadata records five validity flags.
  Analysis settings: Complex: 7XBN; rank: 3; score: 0.63. Displayed screen: ligand-protein heavy-atom distances below 2.2 angstrom.
  Cutoffs: distance: 2.2 angstrom

## Uncertainty

- general: The figure displays geometric close-contact proxies. Regenerating all five recorded validity flags requires the upstream validation inputs and software context.
## Scene files and images

- PyMOL scene: `native/case03_real_validity_failure_7xbn_rank3.pml`
- Rendered panel: `renders/case03_real_validity_failure_7xbn_rank3.png`
- PyMOL session: `native/case03_real_validity_failure_7xbn_rank3.pse`

## Reproduce the figure

ClaimTrace imports saved scene instructions. Open the scene in its original viewer to check loading, selections, and the saved view. Assess the scientific claim using the linked evidence and limitations.
Replay only native scripts you trust. Review raw or unknown commands first, and use an isolated, network-restricted viewer when provenance is uncertain.
- PyMOL scene: `native/case03_real_validity_failure_7xbn_rank3.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol case03_real_validity_failure_7xbn_rank3.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\case03_real_validity_failure_7xbn_rank3.pml'`
- PyMOL session: open `native/case03_real_validity_failure_7xbn_rank3.pse` in a compatible local PyMOL version.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Observed scene operations:
- `op:pymol:83177aa1ebac`: reinitialized `scene`
- `op:pymol:b75c46ee2563`: background_colored `scene` - Scene background is colored `white`. Tool suggestion (unconfirmed): Color visually distinguishes `scene`; no scientific meaning is inferred.
- `op:pymol:d34c6e5e4847`: configured `global`
- `op:pymol:2b29adcac420`: configured `global`
- `op:pymol:5ccda8cab495`: configured `global`
- `op:pymol:e2371893ff4e`: configured `global`
- `op:pymol:62c190846a31`: configured `global`
- `op:pymol:565b9dcb1e72`: configured `global`
- `op:pymol:35c3802f9874`: configured `global`
- `op:pymol:379c1d46f1fa`: configured `global`
- `op:pymol:b39bf482f18b`: configured `global`
- `op:pymol:639353087fe3`: configured `global`
- `op:pymol:0f896a72a948`: configured `global`
- `op:pymol:8f5f72af2595`: configured `global`
- `op:pymol:bf29eb43c83b`: configured `global`
- `op:pymol:a40507cc5ce6`: configured `global`
- `op:pymol:77fe3b6571f8`: configured `global`
- `op:pymol:2961a26fb62b`: configured `global`
- `op:pymol:41f389b67bbb`: configured `global`
- `op:pymol:b8afef24e8b9`: configured `global`
- `op:pymol:1072ff05cc50`: configured `global`
- `op:pymol:c424b80ba4e5`: configured `global`
- `op:pymol:41b86a4ea5ed`: configured `global`
- `op:pymol:fa27edcd030a`: configured `global`
- `op:pymol:140aecac7c5a`: configured `global`
- `op:pymol:321339103578`: configured `global`
- `op:pymol:40171498ce7b`: configured `global`
- `op:pymol:aea542cf2c39`: configured `global`
- `op:pymol:afdba3d24639`: configured `global`
- `op:pymol:d3ccd81f8246`: configured `global`
- `op:pymol:435bb036b031`: configured `global`
- `op:pymol:3aa2e8e75b40`: configured `global`
- `op:pymol:5acaea3eaa9c`: custom_color_defined `retained_green` - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:ecf02659894b`: custom_color_defined `removed_gray` - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:361109d06d40`: custom_color_defined `warning_orange` - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:dd9363a4637e`: custom_color_defined `provenance_blue` - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:1fd7f4a02342`: custom_color_defined `protein_gray` - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:81a1e2cd4b64`: custom_color_defined `pocket_gray` - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:85984a12519b`: custom_color_defined `protein_surface_gray` - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:e072ed78e1bc`: custom_color_defined `ligand_carbon` - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:b8ed6a050d09`: custom_color_defined `water_blue` - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:18c451876b22`: custom_color_defined `oxygen_red` - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:5ea722e64c78`: custom_color_defined `nitrogen_blue` - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:c807ba337b86`: custom_color_defined `sulfur_yellow` - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:d0c3efd1e81b`: custom_color_defined `chlorine_green` - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:6a565d51ac3b`: loaded `receptor`
- `op:pymol:31eb066dfd5e`: loaded `failed_pose`
- `op:pymol:9562f0070289`: atoms_removed `elem H`
- `op:pymol:34a058bc82f6`: hidden `all`
- `op:pymol:24d9f1864e30`: displayed `context`
- `op:pymol:2e9850b7741d`: simplified `context`
- `op:pymol:a57d2d7f892f`: colored `context` - Target `context` is colored `protein_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `context`; no scientific meaning is inferred.
- `op:pymol:f6073b7c4c65`: configured `context`
- `op:pymol:a536092c192c`: transparency_changed `context` - Target `context` has transparency `0.66`. Tool suggestion (unconfirmed): Transparency changes the presentation of `context`; no scientific meaning is inferred.
- `op:pymol:2f1c91b9dede`: created `pocket_surface`
- `op:pymol:7939b8b21875`: displayed `pocket_surface`
- `op:pymol:f8a2eb1fd353`: simplified `pocket_surface`
- `op:pymol:a520c00cc0e3`: colored `pocket_surface` - Target `pocket_surface` is colored `protein_surface_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `pocket_surface`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:9982d940ed8e`: configured `pocket_surface`
- `op:pymol:d20ead1ecfb8`: transparency_changed `pocket_surface` - Target `pocket_surface` has transparency `0.52`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:52c2fed134ca`: configured `pocket_surface`
- `op:pymol:d1bd66f47360`: displayed `pocket`
- `op:pymol:2b3d59f87b1f`: hidden `pocket and elem H`
- `op:pymol:5cc8e238ccbf`: colored `pocket and elem C` - Target `pocket and elem C` is colored `pocket_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `pocket and elem C`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:593a2b614f63`: configured `pocket`
- `op:pymol:893390ea0dc4`: configured `pocket`
- `op:pymol:867845bcd9c8`: transparency_changed `pocket` - Target `pocket` has transparency `0.40`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:0ffa6fe2df03`: displayed `clash_region and receptor`
- `op:pymol:1f9037ed0268`: colored `clash_region and receptor and elem C` - Target `clash_region and receptor and elem C` is colored `provenance_blue`. Tool suggestion (unconfirmed): Color visually distinguishes `clash_region and receptor and elem C`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:72a459eefc07`: configured `clash_region and receptor`
- `op:pymol:a5f260f070b5`: configured `clash_region and receptor`
- `op:pymol:8d10ce031816`: transparency_changed `clash_region and receptor` - Target `clash_region and receptor` has transparency `0.05`. Tool suggestion (unconfirmed): Transparency changes the presentation of `clash_region and receptor`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:e60a3cb36124`: displayed `failed_pose`
- `op:pymol:37997ec7a1a6`: configured `failed_pose`
- `op:pymol:ff94dbdc07aa`: configured `failed_pose`
- `op:pymol:9f0bfb947660`: transparency_changed `failed_pose` - Target `failed_pose` has transparency `0.0`. Tool suggestion (unconfirmed): Transparency changes the presentation of `failed_pose`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:91a1751063d4`: colored `(failed_pose) and elem C` - Target `(failed_pose) and elem C` is colored `ligand_carbon`. Tool suggestion (unconfirmed): Color visually distinguishes `(failed_pose) and elem C`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:a59b8525040f`: colored `(failed_pose) and elem O` - Target `(failed_pose) and elem O` is colored `oxygen_red`. Tool suggestion (unconfirmed): Color visually distinguishes `(failed_pose) and elem O`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:d77e369bf38d`: colored `(failed_pose) and elem N` - Target `(failed_pose) and elem N` is colored `nitrogen_blue`. Tool suggestion (unconfirmed): Color visually distinguishes `(failed_pose) and elem N`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:c25f3d4c277f`: colored `(failed_pose) and elem S` - Target `(failed_pose) and elem S` is colored `sulfur_yellow`. Tool suggestion (unconfirmed): Color visually distinguishes `(failed_pose) and elem S`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:346371965620`: colored `(failed_pose) and elem CL` - Target `(failed_pose) and elem CL` is colored `chlorine_green`. Tool suggestion (unconfirmed): Color visually distinguishes `(failed_pose) and elem CL`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:e0347e2992d1`: measurement_intent `close_contact_proxy`
- `op:pymol:1483884418b2`: colored `close_contact_proxy` - Target `close_contact_proxy` is colored `warning_orange`. Tool suggestion (unconfirmed): Color visually distinguishes `close_contact_proxy`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:4c124fa4c196`: hidden `close_contact_proxy`
- `op:pymol:8d4d4f9873db`: configured `close_contact_proxy`
- `op:pymol:3e62d6722d05`: displayed `close_ligand or close_protein`
- `op:pymol:3316fb8c97c8`: configured `close_ligand`
- `op:pymol:91e607ee4779`: configured `close_protein`
- `op:pymol:1235cd927852`: configured `close_ligand`
- `op:pymol:75f465c0567a`: transparency_changed `close_ligand` - Target `close_ligand` has transparency `0.08`. Tool suggestion (unconfirmed): Transparency changes the presentation of `close_ligand`; no scientific meaning is inferred.
- `op:pymol:6ec1708c8b98`: configured `close_protein`
- `op:pymol:6617f5b44907`: transparency_changed `close_protein` - Target `close_protein` has transparency `0.24`. Tool suggestion (unconfirmed): Transparency changes the presentation of `close_protein`; no scientific meaning is inferred.
- `op:pymol:3f093ba16f1f`: colored `close_ligand` - Target `close_ligand` is colored `warning_orange`. Tool suggestion (unconfirmed): Color may highlight the ligand or ligand selection; confirm if it carries the panel message. Confirmation needed.
- `op:pymol:be4e17437bf5`: colored `close_protein` - Target `close_protein` is colored `provenance_blue`. Tool suggestion (unconfirmed): Color visually distinguishes the protein or protein selection; no scientific meaning is inferred.
- `op:pymol:06846173ba70`: camera_oriented `failed_pose or clash_region`
- `op:pymol:23f60097947a`: camera_zoomed `failed_pose or clash_region`
- `op:pymol:0257ba18aec8`: clipped `scene`
- `op:pymol:efb6fbcd70f5`: ray_traced `scene`
- `op:pymol:3de9cf45966c`: output_intent `renders/case03_real_validity_failure_7xbn_rank3.png`
- `op:pymol:49b7e2173953`: output_intent `renders/case03_real_validity_failure_7xbn_rank3.pse`
- `op:pymol:92fa08e9b015`: session_terminated `session`

Native references needing or containing identity context:
- `native-ref:pymol:8cff88e27c61`: `receptor` -> data/docking/case03_7xbn_receptor/protein.pdbqt
- `native-ref:pymol:a1c75338975d`: `failed_pose` -> data/docking/case03_7xbn_pose/rank3_score0.63.sdf

Native resource references:
- `resource:pymol:522ea8c97363` (relative, fixity available): `data/docking/case03_7xbn_receptor/protein.pdbqt`
- `resource:pymol:4d6bcccd37fc` (relative, fixity available): `data/docking/case03_7xbn_pose/rank3_score0.63.sdf`

## Scene details

### scene:85b2947d056e

Recorded view or figure settings: Source PML: orient failed_pose or clash_region; zoom failed_pose or clash_region, 4.8; clip slab, 28. Viewer replay remains pending.

Automatically observed native scene operations:
- reinitialized `scene` (command=reinitialize)
- background_colored `scene` (command=bg_color) - Scene background is colored `white`. Suggested meaning awaiting review: Color visually distinguishes `scene`; no scientific meaning is inferred.
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=20)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=0)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=0.20)
- configured `global` (command=set, value=0.80)
- configured `global` (command=set, value=0.08)
- configured `global` (command=set, value=12)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=2)
- configured `global` (command=set, value=14)
- configured `global` (command=set, value=8)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.46)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=10)
- configured `global` (command=set, value=24)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.045)
- configured `global` (command=set, value=0.14)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=2.0)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=0.16)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=18)
- custom_color_defined `retained_green` (command=set_color) - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `removed_gray` (command=set_color) - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `warning_orange` (command=set_color) - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `provenance_blue` (command=set_color) - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_gray` (command=set_color) - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `pocket_gray` (command=set_color) - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_surface_gray` (command=set_color) - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `ligand_carbon` (command=set_color) - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `water_blue` (command=set_color) - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `oxygen_red` (command=set_color) - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `nitrogen_blue` (command=set_color) - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `sulfur_yellow` (command=set_color) - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `chlorine_green` (command=set_color) - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- loaded `receptor` (command=load)
- loaded `failed_pose` (command=load)
- atoms_removed `elem H` (command=remove)
- hidden `all` (command=hide)
- displayed `context` (command=show)
- simplified `context` (command=show)
- colored `context` (command=color) - Target `context` is colored `protein_gray`. Suggested meaning awaiting review: Color visually distinguishes `context`; no scientific meaning is inferred.
- configured `context` (command=set, value=0.66)
- transparency_changed `context` (command=set, value=0.66) - Target `context` has transparency `0.66`. Suggested meaning awaiting review: Transparency changes the presentation of `context`; no scientific meaning is inferred.
- created `pocket_surface` (command=create)
- displayed `pocket_surface` (command=show)
- simplified `pocket_surface` (command=show)
- colored `pocket_surface` (command=color) - Target `pocket_surface` is colored `protein_surface_gray`. Suggested meaning awaiting review: Color visually distinguishes `pocket_surface`; no scientific meaning is inferred.
- configured `pocket_surface` (command=set, value=0.52)
- transparency_changed `pocket_surface` (command=set, value=0.52) - Target `pocket_surface` has transparency `0.52`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred.
- configured `pocket_surface` (command=set, value=1)
- displayed `pocket` (command=show)
- hidden `pocket and elem H` (command=hide)
- colored `pocket and elem C` (command=color) - Target `pocket and elem C` is colored `pocket_gray`. Suggested meaning awaiting review: Color visually distinguishes `pocket and elem C`; no scientific meaning is inferred.
- configured `pocket` (command=set, value=0.085)
- configured `pocket` (command=set, value=0.40)
- transparency_changed `pocket` (command=set, value=0.40) - Target `pocket` has transparency `0.40`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket`; no scientific meaning is inferred.
- displayed `clash_region and receptor` (command=show)
- colored `clash_region and receptor and elem C` (command=color) - Target `clash_region and receptor and elem C` is colored `provenance_blue`. Suggested meaning awaiting review: Color visually distinguishes `clash_region and receptor and elem C`; no scientific meaning is inferred.
- configured `clash_region and receptor` (command=set, value=0.15)
- configured `clash_region and receptor` (command=set, value=0.05)
- transparency_changed `clash_region and receptor` (command=set, value=0.05) - Target `clash_region and receptor` has transparency `0.05`. Suggested meaning awaiting review: Transparency changes the presentation of `clash_region and receptor`; no scientific meaning is inferred.
- displayed `failed_pose` (command=show)
- configured `failed_pose` (command=set, value=0.27)
- configured `failed_pose` (command=set, value=0.0)
- transparency_changed `failed_pose` (command=set, value=0.0) - Target `failed_pose` has transparency `0.0`. Suggested meaning awaiting review: Transparency changes the presentation of `failed_pose`; no scientific meaning is inferred.
- colored `(failed_pose) and elem C` (command=color) - Target `(failed_pose) and elem C` is colored `ligand_carbon`. Suggested meaning awaiting review: Color visually distinguishes `(failed_pose) and elem C`; no scientific meaning is inferred.
- colored `(failed_pose) and elem O` (command=color) - Target `(failed_pose) and elem O` is colored `oxygen_red`. Suggested meaning awaiting review: Color visually distinguishes `(failed_pose) and elem O`; no scientific meaning is inferred.
- colored `(failed_pose) and elem N` (command=color) - Target `(failed_pose) and elem N` is colored `nitrogen_blue`. Suggested meaning awaiting review: Color visually distinguishes `(failed_pose) and elem N`; no scientific meaning is inferred.
- colored `(failed_pose) and elem S` (command=color) - Target `(failed_pose) and elem S` is colored `sulfur_yellow`. Suggested meaning awaiting review: Color visually distinguishes `(failed_pose) and elem S`; no scientific meaning is inferred.
- colored `(failed_pose) and elem CL` (command=color) - Target `(failed_pose) and elem CL` is colored `chlorine_green`. Suggested meaning awaiting review: Color visually distinguishes `(failed_pose) and elem CL`; no scientific meaning is inferred.
- measurement_intent `close_contact_proxy` (command=distance)
- colored `close_contact_proxy` (command=color) - Target `close_contact_proxy` is colored `warning_orange`. Suggested meaning awaiting review: Color visually distinguishes `close_contact_proxy`; no scientific meaning is inferred.
- hidden `close_contact_proxy` (command=hide)
- configured `close_contact_proxy` (command=set, value=2.4)
- displayed `close_ligand or close_protein` (command=show)
- configured `close_ligand` (command=set, value=0.24)
- configured `close_protein` (command=set, value=0.18)
- configured `close_ligand` (command=set, value=0.08)
- transparency_changed `close_ligand` (command=set, value=0.08) - Target `close_ligand` has transparency `0.08`. Suggested meaning awaiting review: Transparency changes the presentation of `close_ligand`; no scientific meaning is inferred.
- configured `close_protein` (command=set, value=0.24)
- transparency_changed `close_protein` (command=set, value=0.24) - Target `close_protein` has transparency `0.24`. Suggested meaning awaiting review: Transparency changes the presentation of `close_protein`; no scientific meaning is inferred.
- colored `close_ligand` (command=color) - Target `close_ligand` is colored `warning_orange`. Suggested meaning awaiting review: Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- colored `close_protein` (command=color) - Target `close_protein` is colored `provenance_blue`. Suggested meaning awaiting review: Color visually distinguishes the protein or protein selection; no scientific meaning is inferred.
- camera_oriented `failed_pose or clash_region` (command=orient)
- camera_zoomed `failed_pose or clash_region` (command=zoom)
- clipped `scene` (command=clip)
- ray_traced `scene` (command=ray)
- output_intent `renders/case03_real_validity_failure_7xbn_rank3.png` (command=png)
- output_intent `renders/case03_real_validity_failure_7xbn_rank3.pse` (command=save)
- session_terminated `session` (command=quit)

</details>

## Molecules and selections

Recorded molecules: 0; selections: 5. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.
Open **Selected regions** in the GUI to inspect the recorded selections and their source commands.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 1
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Required checks passed for `draft`.

Recommended:
- `CLAIM.LIGAND.IDENTITY_CONTEXT`: A ligand-binding claim needs stable ligand and binding-site/residue identities linked to its evidence.
  Edit: `/claims/0/evidence_ids`
  Next: Add ligand and residue entities with stable identities, then target them from the evidence entry.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; CC-BY-4.0 for Multi-Paradigm docking benchmark, Zenodo 19560204. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
