# Figure 1B3 - Confidence and geometry

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 1B3
- Claim: AlphaFold confidence and backbone geometry provide complementary checks of the P69441 model.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/3_1_alphafold_plddt.png`, `renders/3_2_ramachandran_general.png`
- Evidence summary: Review the model confidence values and supplied Ramachandran assessment.: The model has pLDDT values from 87.88 to 98.62. The supplied geometry assessment covers 212 residues: 209 favored, 3 allowed and 0 outliers. The displayed general-residue panel contains 144 residues.
- Visual meanings: colored on `af_adk`: The PML colors the B-factor pLDDT field from red (0) to blue (100). The original PSE records a narrower 87.5-99 display range.
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Review the model confidence values and supplied Ramachandran assessment.: The model has pLDDT values from 87.88 to 98.62. The supplied geometry assessment covers 212 residues: 209 favored, 3 allowed and 0 outliers. The displayed general-residue panel contains 144 residues.

## Visual meanings

- colored on `af_adk`: The PML colors the B-factor pLDDT field from red (0) to blue (100). The original PSE records a narrower 87.5-99 display range.

## Open items and limits

- Required checks passed for `draft` export
- Additional review items: 3; see `human_review_required` in `validation_report.json`.
- Scope: Imported scene instructions preserve visual context. Viewer loading, selections, and rendered output require a replay check.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: 2 present / 2 present
- Structure/map files: 1 present
- Evidence entries: 1 recorded
- Dedicated evidence/validation files: 2 present
- `Figure 1B3`: AlphaFold confidence and backbone geometry provide complementary checks of the P69441 model.
  Renders: `renders/3_2_ramachandran_general.png` (Rendered panel), `renders/3_1_alphafold_plddt.png` (Rendered panel)
  Native files: `native/3_1_alphafold_plddt.pml` (PyMOL scene)
  Supporting files: `data/3_2_ramachandran.csv` (Validation report), `native/3_1_alphafold_plddt.pse` (PyMOL session), `data/3_2_ramachandran.json` (Validation report), `native/data/alphafold_p69441/AF-P69441-F1-model_v6.cif` (Structure file)

## Claims

### Figure 1B3

- Text: AlphaFold confidence and backbone geometry provide complementary checks of the P69441 model.
- Type: computed_model_claim
- Figure/panel: Figure 1B3
- Linked scenes: 1
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- external validation
  Claim link: claim:gui:631efe4545df
  How it was checked: Review the model confidence values and supplied Ramachandran assessment.
  Source files: `data/3_2_ramachandran.csv` (Validation report), `native/3_1_alphafold_plddt.pse` (PyMOL session), `data/3_2_ramachandran.json` (Validation report), `native/data/alphafold_p69441/AF-P69441-F1-model_v6.cif` (Structure file)
  Observation: The model has pLDDT values from 87.88 to 98.62. The supplied geometry assessment covers 212 residues: 209 favored, 3 allowed and 0 outliers. The displayed general-residue panel contains 144 residues.
  Analysis settings: Model: AF-P69441-F1 v6. Confidence: pLDDT, 0-100. Geometry assessment: the same model, 212 assessed residues; general-residue panel: 144 residues.

## Uncertainty

- general: Confidence and backbone geometry address different properties. The supplied PML specifies a 0-100 color range; the original PSE records a narrower 87.5-99 range. Match the color key to the saved scene when checking replay.
## Scene files and images

- PyMOL scene: `native/3_1_alphafold_plddt.pml`
- Rendered panel: `renders/3_1_alphafold_plddt.png`
- Rendered panel: `renders/3_2_ramachandran_general.png`
- PyMOL session: `native/3_1_alphafold_plddt.pse`

## Reproduce the figure

ClaimTrace imports saved scene instructions. Open the scene in its original viewer to check loading, selections, and the saved view. Assess the scientific claim using the linked evidence and limitations.
Replay only native scripts you trust. Review raw or unknown commands first, and use an isolated, network-restricted viewer when provenance is uncertain.
- PyMOL scene: `native/3_1_alphafold_plddt.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol 3_1_alphafold_plddt.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\3_1_alphafold_plddt.pml'`
- PyMOL session: open `native/3_1_alphafold_plddt.pse` in a compatible local PyMOL version.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Observed scene operations:
- `op:pymol:4f8f2158e5a4`: loaded `af_adk`
- `op:pymol:85fa526f9e7f`: displayed `af_adk`
- `op:pymol:84f6939cbc9b`: simplified `af_adk`
- `op:pymol:fd162c436fe8`: colored `af_adk` - Target `af_adk` is colored `spectrum:red_yellow_green_cyan_blue`. Author confirmed: The PML colors the B-factor pLDDT field from red (0) to blue (100). The original PSE records a narrower 87.5-99 display range.
- `op:pymol:53d4daa6f50a`: camera_set `scene`

Author-reviewed operation meanings and remaining suggestions:
- `op:pymol:fd162c436fe8`: user_confirmed_meaning; author confirmed: The PML colors the B-factor pLDDT field from red (0) to blue (100). The original PSE records a narrower 87.5-99 display range.

Native references needing or containing identity context:
- `native-ref:pymol:60142ea9414c`: `af_adk` -> data/alphafold_p69441/AF-P69441-F1-model_v6.cif

Native resource references:
- `resource:pymol:546bb47a1de1` (relative, fixity available): `data/alphafold_p69441/AF-P69441-F1-model_v6.cif`

## Scene details

### scene:cdc4874f6de6

Automatically observed native scene operations:
- loaded `af_adk` (command=load)
- displayed `af_adk` (command=show)
- simplified `af_adk` (command=show)
- colored `af_adk` (command=spectrum, method=spectrum) - Target `af_adk` is colored `spectrum:red_yellow_green_cyan_blue`. Author confirmed: The PML colors the B-factor pLDDT field from red (0) to blue (100). The original PSE records a narrower 87.5-99 display range.
- camera_set `scene` (command=set_view)

</details>

## Molecules and selections

Recorded molecules: 0; selections: 0. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 0
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Package checks passed for `draft` mode.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; CC-BY-4.0 for AlphaFold DB model AF-P69441-F1 v6. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
