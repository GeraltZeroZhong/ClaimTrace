reinitialize
bg_color white
set orthoscopic, on
set field_of_view, 20
set antialias, 3
set ray_trace_mode, 0
set ray_opaque_background, off
set ray_shadows, off
set ambient, 0.20
set direct, 0.80
set spec_reflect, 0.08
set shininess, 12
set two_sided_lighting, on
set ambient_occlusion_mode, 2
set ambient_occlusion_scale, 14
set ambient_occlusion_smooth, 8
set depth_cue, on
set fog, on
set fog_start, 0.46
set cartoon_fancy_helices, on
set cartoon_sampling, 10
set stick_quality, 24
set sphere_quality, 3
set valence, on
set valence_size, 0.045
set stick_radius, 0.14
set sphere_scale, 0.28
set dash_width, 2.0
set dash_gap, 0.28
set dash_length, 0.16
set dash_round_ends, on
set label_size, 18
set_color retained_green, [0.000, 0.620, 0.451]
set_color removed_gray, [0.557, 0.596, 0.659]
set_color warning_orange, [0.835, 0.369, 0.000]
set_color provenance_blue, [0.000, 0.447, 0.698]
set_color protein_gray, [0.835, 0.878, 0.894]
set_color pocket_gray, [0.325, 0.416, 0.447]
set_color protein_surface_gray, [0.757, 0.816, 0.839]
set_color ligand_carbon, [0.090, 0.302, 0.329]
set_color water_blue, [0.337, 0.706, 0.914]
set_color oxygen_red, [0.698, 0.227, 0.180]
set_color nitrogen_blue, [0.275, 0.361, 0.612]
set_color sulfur_yellow, [0.769, 0.573, 0.000]
set_color chlorine_green, [0.176, 0.498, 0.369]
load data/docking/case03_7xbn_receptor/protein.pdbqt, receptor
load data/docking/case03_7xbn_pose/rank3_score0.63.sdf, failed_pose
remove elem H
hide everything
select close_ligand, failed_pose within 2.2 of receptor
select close_protein, receptor within 2.2 of failed_pose
select clash_region, byres (close_ligand or close_protein)
select pocket, byres (receptor within 5.0 of failed_pose)
select context, byres (receptor within 7.0 of failed_pose)
show cartoon, context
color protein_gray, context
set cartoon_transparency, 0.66, context
create pocket_surface, pocket
show surface, pocket_surface
color protein_surface_gray, pocket_surface
set transparency, 0.52, pocket_surface
set surface_quality, 1, pocket_surface
show sticks, pocket
hide sticks, pocket and elem H
color pocket_gray, pocket and elem C
set stick_radius, 0.085, pocket
set stick_transparency, 0.40, pocket
show sticks, clash_region and receptor
color provenance_blue, clash_region and receptor and elem C
set stick_radius, 0.15, clash_region and receptor
set stick_transparency, 0.05, clash_region and receptor
show sticks, failed_pose
set stick_radius, 0.27, failed_pose
set stick_transparency, 0.0, failed_pose
color ligand_carbon, (failed_pose) and elem C
color oxygen_red, (failed_pose) and elem O
color nitrogen_blue, (failed_pose) and elem N
color sulfur_yellow, (failed_pose) and elem S
color chlorine_green, (failed_pose) and elem CL
distance close_contact_proxy, failed_pose, receptor, 2.2, 0
color warning_orange, close_contact_proxy
hide labels, close_contact_proxy
set dash_width, 2.4, close_contact_proxy
show spheres, close_ligand or close_protein
set sphere_scale, 0.24, close_ligand
set sphere_scale, 0.18, close_protein
set sphere_transparency, 0.08, close_ligand
set sphere_transparency, 0.24, close_protein
color warning_orange, close_ligand
color provenance_blue, close_protein
orient failed_pose or clash_region
zoom failed_pose or clash_region, 4.8
clip slab, 28
ray 2400, 1600
png renders/case03_real_validity_failure_7xbn_rank3.png, dpi=600
save renders/case03_real_validity_failure_7xbn_rank3.pse
quit
