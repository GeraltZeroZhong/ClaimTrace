# Figure 4D - Asp110-ligand distance

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 4D
- Claim: The 3PBL view shows Asp110 OD2 and eticlopride N2 separated by 2.702419 angstrom.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/case04_real_3pbl_eticlopride_asp110.png`
- Evidence summary: Inspect the two selected atoms in 3PBL and review the separately supplied dyn106 setup table.: The 3PBL chain A coordinates place Asp110 OD2 2.702419 angstrom from ETQ1200 N2. The separate dyn106 setup table records ACEMD/GPUGRID, CHARMM36m, TIP3P, POPC and a 4 fs timestep.
- Visual meanings: colored on `context`: Light gray identifies the surrounding receptor context.; colored on `pocket_surface`: Pale gray identifies the pocket surface.
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Inspect the two selected atoms in 3PBL and review the separately supplied dyn106 setup table.: The 3PBL chain A coordinates place Asp110 OD2 2.702419 angstrom from ETQ1200 N2. The separate dyn106 setup table records ACEMD/GPUGRID, CHARMM36m, TIP3P, POPC and a 4 fs timestep.

## Visual meanings

- colored on `context`: Light gray identifies the surrounding receptor context.
- colored on `pocket_surface`: Pale gray identifies the pocket surface.
- colored on `pocket and elem C`: Gray identifies carbon atoms in the pocket.
- colored on `(ligand) and elem C`: Teal identifies ligand carbon atoms.
- colored on `(ligand) and elem O`: Red identifies ligand oxygen atoms.
- colored on `(ligand) and elem N`: Blue identifies ligand nitrogen atoms.
- colored on `(ligand) and elem S`: Yellow identifies ligand sulfur atoms.
- colored on `(ligand) and elem CL`: Green identifies ligand chlorine atoms.
- colored on `asp110 and elem C`: Blue identifies Asp110 carbon atoms.
- colored on `asp110 and elem O`: Red identifies Asp110 oxygen atoms.
- colored on `asp110_eticlopride_proxy`: The green distance guide joins Asp110 OD2 and eticlopride N2.

## Open items and limits

- Required checks passed for `draft` export
- Additional review items: 20; see `human_review_required` in `validation_report.json`.
- Scope: Imported scene instructions preserve visual context. Viewer loading, selections, and rendered output require a replay check.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: 2 present / 1 present
- Structure/map files: 1 present
- Evidence entries: 2 recorded
- Dedicated evidence/validation files: 2 present
- `Figure 4D`: The 3PBL view shows Asp110 OD2 and eticlopride N2 separated by 2.702419 angstrom.
  Renders: `renders/case04_real_3pbl_eticlopride_asp110.png` (Rendered panel)
  Native files: `native/case04_real_3pbl_eticlopride_asp110.pml` (PyMOL scene)
  Supporting files: `native/case04_real_3pbl_eticlopride_asp110.pml` (PyMOL scene), `native/data/structures/3PBL.pdb` (Structure file), `data/gpcrmd_dyn106_setup_metadata.csv` (Evidence note), `data/gpcrmd_dyn106_system_counts.csv` (Evidence note)

## Claims

### Figure 4D

- Text: The 3PBL view shows Asp110 OD2 and eticlopride N2 separated by 2.702419 angstrom.
- Type: simple_structure_view
- Figure/panel: Figure 4D
- Linked scenes: 1
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- measurement
  Claim link: claim link pending
  How it was checked: PyMOL distance command
  Source files: `native/case04_real_3pbl_eticlopride_asp110.pml` (PyMOL scene)
  Observation: Distance/measurement intent observed in PyMOL script; not classified as a hydrogen bond or contact.
- measurement
  Claim link: claim:gui:91fa76f10ccd
  How it was checked: Inspect the two selected atoms in 3PBL and review the separately supplied dyn106 setup table.
  Source files: `native/case04_real_3pbl_eticlopride_asp110.pml` (PyMOL scene), `native/data/structures/3PBL.pdb` (Structure file), `data/gpcrmd_dyn106_setup_metadata.csv` (Evidence note), `data/gpcrmd_dyn106_system_counts.csv` (Evidence note)
  Observation: The 3PBL chain A coordinates place Asp110 OD2 2.702419 angstrom from ETQ1200 N2. The separate dyn106 setup table records ACEMD/GPUGRID, CHARMM36m, TIP3P, POPC and a 4 fs timestep.
  Analysis settings: Displayed structure: PDB 3PBL, chain A; atom pair: Asp110 OD2 and ETQ1200 N2. Setup context: GPCRmd dyn106, from the supplied metadata table.
  Measured distance: 2.702419 angstrom

## Uncertainty

- general: The distance describes the static 3PBL structure. GPCRmd dyn106 supplies separate simulation context. Its TIP row reports 8,134 residues and 54,390 atoms; resolve that count against the original topology before using it as a system total.
## Scene files and images

- PyMOL scene: `native/case04_real_3pbl_eticlopride_asp110.pml`
- Rendered panel: `renders/case04_real_3pbl_eticlopride_asp110.png`
- PyMOL session: `native/case04_real_3pbl_eticlopride_asp110.pse`

## Reproduce the figure

ClaimTrace imports saved scene instructions. Open the scene in its original viewer to check loading, selections, and the saved view. Assess the scientific claim using the linked evidence and limitations.
Replay only native scripts you trust. Review raw or unknown commands first, and use an isolated, network-restricted viewer when provenance is uncertain.
- PyMOL scene: `native/case04_real_3pbl_eticlopride_asp110.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol case04_real_3pbl_eticlopride_asp110.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\case04_real_3pbl_eticlopride_asp110.pml'`
- PyMOL session: open `native/case04_real_3pbl_eticlopride_asp110.pse` in a compatible local PyMOL version.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Observed scene operations:
- `op:pymol:3926e9a79039`: reinitialized `scene`
- `op:pymol:3747065b5cc9`: background_colored `scene` - Scene background is colored `white`. Tool suggestion (unconfirmed): Color visually distinguishes `scene`; no scientific meaning is inferred.
- `op:pymol:ec5c8aae4159`: configured `global`
- `op:pymol:8f600d80b7ee`: configured `global`
- `op:pymol:844ee83b4ac9`: configured `global`
- `op:pymol:0359b0b6d7d6`: configured `global`
- `op:pymol:2b9dcd14e854`: configured `global`
- `op:pymol:9eebcd84c70a`: configured `global`
- `op:pymol:15c3d3f4c26b`: configured `global`
- `op:pymol:6a30d1e7de51`: configured `global`
- `op:pymol:0b0e792b7c4d`: configured `global`
- `op:pymol:47024bf38b00`: configured `global`
- `op:pymol:0bfad2631b60`: configured `global`
- `op:pymol:fc359c61ec87`: configured `global`
- `op:pymol:20edda3d6501`: configured `global`
- `op:pymol:b79941d63c65`: configured `global`
- `op:pymol:aad3f6815a34`: configured `global`
- `op:pymol:46f3d4742f3a`: configured `global`
- `op:pymol:50c7f1a1406c`: configured `global`
- `op:pymol:d64facdf973f`: configured `global`
- `op:pymol:746e27dc7652`: configured `global`
- `op:pymol:8da54bb396c4`: configured `global`
- `op:pymol:ec7e06e36bbd`: configured `global`
- `op:pymol:32d8b24f9dbf`: configured `global`
- `op:pymol:b87ae3cefd11`: configured `global`
- `op:pymol:6721c565f0ac`: configured `global`
- `op:pymol:4454a3814459`: configured `global`
- `op:pymol:53cd88b5d8a4`: configured `global`
- `op:pymol:352f65487221`: configured `global`
- `op:pymol:120952dfcfd7`: configured `global`
- `op:pymol:3527deebac02`: configured `global`
- `op:pymol:03d7cf4a9798`: configured `global`
- `op:pymol:a9c80e2ba52c`: custom_color_defined `retained_green` - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:155a4c4cbbb5`: custom_color_defined `removed_gray` - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:da2962be2116`: custom_color_defined `warning_orange` - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:691f530934f9`: custom_color_defined `provenance_blue` - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:5aa33fa1caf8`: custom_color_defined `protein_gray` - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:84cfb6de1c17`: custom_color_defined `pocket_gray` - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:0bcdc2b96b06`: custom_color_defined `protein_surface_gray` - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:9c815c100dd6`: custom_color_defined `ligand_carbon` - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:d6e491870b03`: custom_color_defined `water_blue` - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:67e8a7bd0149`: custom_color_defined `oxygen_red` - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:93480932d6ed`: custom_color_defined `nitrogen_blue` - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:d20dc7c72742`: custom_color_defined `sulfur_yellow` - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:2355542e5eab`: custom_color_defined `chlorine_green` - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:2ba17d7bd178`: loaded `d3r`
- `op:pymol:d63f25a1f771`: atoms_removed `not chain A`
- `op:pymol:0047480509a3`: hidden `all`
- `op:pymol:6d92a7265651`: displayed `context`
- `op:pymol:4ad638b8a819`: simplified `context`
- `op:pymol:ff1bd76f2350`: colored `context` - Target `context` is colored `protein_gray`. Author confirmed: Light gray identifies the surrounding receptor context.
- `op:pymol:a19cf5a6914c`: configured `context`
- `op:pymol:1800020471c7`: transparency_changed `context` - Target `context` has transparency `0.64`. Tool suggestion (unconfirmed): Transparency changes the presentation of `context`; no scientific meaning is inferred.
- `op:pymol:cead92cfcb72`: created `pocket_surface`
- `op:pymol:10033dce0da7`: displayed `pocket_surface`
- `op:pymol:90dd920476f8`: simplified `pocket_surface`
- `op:pymol:4275b7b2f0cf`: colored `pocket_surface` - Target `pocket_surface` is colored `protein_surface_gray`. Author confirmed: Pale gray identifies the pocket surface.
- `op:pymol:ee2ab69e9e1c`: configured `pocket_surface`
- `op:pymol:f358a352fc1b`: transparency_changed `pocket_surface` - Target `pocket_surface` has transparency `0.50`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:a0e2f51c1aa4`: configured `pocket_surface`
- `op:pymol:9dee38d3dc7d`: displayed `pocket`
- `op:pymol:a97d777886a7`: hidden `pocket and elem H`
- `op:pymol:6521bb281b80`: colored `pocket and elem C` - Target `pocket and elem C` is colored `pocket_gray`. Author confirmed: Gray identifies carbon atoms in the pocket.
- `op:pymol:fe726cea6706`: configured `pocket`
- `op:pymol:cfd5d4808ffa`: configured `pocket`
- `op:pymol:267496ce226e`: transparency_changed `pocket` - Target `pocket` has transparency `0.35`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:1f158177beac`: displayed `ligand`
- `op:pymol:7fdd168ea6b0`: configured `ligand`
- `op:pymol:1a8055c1823a`: configured `ligand`
- `op:pymol:b8b025bf8ffd`: transparency_changed `ligand` - Target `ligand` has transparency `0.0`. Tool suggestion (unconfirmed): Transparency changes the presentation of `ligand`; no scientific meaning is inferred.
- `op:pymol:71a15666a706`: colored `(ligand) and elem C` - Target `(ligand) and elem C` is colored `ligand_carbon`. Author confirmed: Teal identifies ligand carbon atoms.
- `op:pymol:0bbb3b8264c6`: colored `(ligand) and elem O` - Target `(ligand) and elem O` is colored `oxygen_red`. Author confirmed: Red identifies ligand oxygen atoms.
- `op:pymol:1f41ab9acbdc`: colored `(ligand) and elem N` - Target `(ligand) and elem N` is colored `nitrogen_blue`. Author confirmed: Blue identifies ligand nitrogen atoms.
- `op:pymol:50cc2ff93239`: colored `(ligand) and elem S` - Target `(ligand) and elem S` is colored `sulfur_yellow`. Author confirmed: Yellow identifies ligand sulfur atoms.
- `op:pymol:d707953662e1`: colored `(ligand) and elem CL` - Target `(ligand) and elem CL` is colored `chlorine_green`. Author confirmed: Green identifies ligand chlorine atoms.
- `op:pymol:5d2ff3781472`: displayed `asp110`
- `op:pymol:af6fa7850a79`: configured `asp110`
- `op:pymol:9023176ab084`: configured `asp110`
- `op:pymol:648309732944`: transparency_changed `asp110` - Target `asp110` has transparency `0.0`. Tool suggestion (unconfirmed): Transparency changes the presentation of `asp110`; no scientific meaning is inferred.
- `op:pymol:d93e174ffc06`: colored `asp110 and elem C` - Target `asp110 and elem C` is colored `provenance_blue`. Author confirmed: Blue identifies Asp110 carbon atoms.
- `op:pymol:2fea554dd0a1`: colored `asp110 and elem O` - Target `asp110 and elem O` is colored `oxygen_red`. Author confirmed: Red identifies Asp110 oxygen atoms.
- `op:pymol:092a2609763a`: displayed `ligand and name N2`
- `op:pymol:f22c91dbc5cb`: displayed `asp110 and name OD2`
- `op:pymol:be8d1215484a`: configured `ligand and name N2`
- `op:pymol:6b27f18f51d4`: configured `asp110 and name OD2`
- `op:pymol:f1604e7836ee`: measurement_intent `asp110_eticlopride_proxy`
- `op:pymol:fb35d98a93cd`: colored `asp110_eticlopride_proxy` - Target `asp110_eticlopride_proxy` is colored `retained_green`. Author confirmed: The green distance guide joins Asp110 OD2 and eticlopride N2.
- `op:pymol:a1c463c5583e`: hidden `asp110_eticlopride_proxy`
- `op:pymol:8069364bece9`: configured `asp110_eticlopride_proxy`
- `op:pymol:91701481ac9d`: camera_oriented `ligand or pocket`
- `op:pymol:bec7d4a97596`: camera_turned `scene`
- `op:pymol:6da4e8be4fbf`: camera_turned `scene`
- `op:pymol:173639beeb44`: camera_zoomed `ligand or pocket or asp110`
- `op:pymol:5007e193aeba`: clipped `scene`
- `op:pymol:93b092b43192`: ray_traced `scene`
- `op:pymol:b26a0f0fa9f3`: output_intent `renders/case04_real_3pbl_eticlopride_asp110.png`
- `op:pymol:01fbf3c27bc2`: output_intent `renders/case04_real_3pbl_eticlopride_asp110.pse`
- `op:pymol:1e0fb0263a2e`: session_terminated `session`

Author-reviewed operation meanings and remaining suggestions:
- `op:pymol:ff1bd76f2350`: user_confirmed_meaning; author confirmed: Light gray identifies the surrounding receptor context.
- `op:pymol:4275b7b2f0cf`: user_confirmed_meaning; author confirmed: Pale gray identifies the pocket surface.
- `op:pymol:6521bb281b80`: user_confirmed_meaning; author confirmed: Gray identifies carbon atoms in the pocket.
- `op:pymol:71a15666a706`: user_confirmed_meaning; author confirmed: Teal identifies ligand carbon atoms.
- `op:pymol:0bbb3b8264c6`: user_confirmed_meaning; author confirmed: Red identifies ligand oxygen atoms.
- `op:pymol:1f41ab9acbdc`: user_confirmed_meaning; author confirmed: Blue identifies ligand nitrogen atoms.
- `op:pymol:50cc2ff93239`: user_confirmed_meaning; author confirmed: Yellow identifies ligand sulfur atoms.
- `op:pymol:d707953662e1`: user_confirmed_meaning; author confirmed: Green identifies ligand chlorine atoms.
- `op:pymol:d93e174ffc06`: user_confirmed_meaning; author confirmed: Blue identifies Asp110 carbon atoms.
- `op:pymol:2fea554dd0a1`: user_confirmed_meaning; author confirmed: Red identifies Asp110 oxygen atoms.
- `op:pymol:fb35d98a93cd`: user_confirmed_meaning; author confirmed: The green distance guide joins Asp110 OD2 and eticlopride N2.

Native references needing or containing identity context:
- `native-ref:pymol:a658e10da6b6`: `d3r` -> data/structures/3PBL.pdb

Native resource references:
- `resource:pymol:e3fadb5bc15f` (relative, fixity available): `data/structures/3PBL.pdb`

## Scene details

### scene:5e7ae7fc844f

Recorded view or figure settings: Open case04_real_3pbl_eticlopride_asp110.pse. The script orients ligand or pocket, turns y by -20 and x by 10, zooms ligand or pocket or asp110 by 4.2, and clips a slab of 30.

Automatically observed native scene operations:
- reinitialized `scene` (command=reinitialize)
- background_colored `scene` (command=bg_color) - Scene background is colored `white`. Suggested meaning awaiting review: Color visually distinguishes `scene`; no scientific meaning is inferred.
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=20)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=0)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=0.20)
- configured `global` (command=set, value=0.80)
- configured `global` (command=set, value=0.08)
- configured `global` (command=set, value=12)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=2)
- configured `global` (command=set, value=14)
- configured `global` (command=set, value=8)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.46)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=10)
- configured `global` (command=set, value=24)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.045)
- configured `global` (command=set, value=0.14)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=2.0)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=0.16)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=18)
- custom_color_defined `retained_green` (command=set_color) - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `removed_gray` (command=set_color) - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `warning_orange` (command=set_color) - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `provenance_blue` (command=set_color) - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_gray` (command=set_color) - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `pocket_gray` (command=set_color) - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_surface_gray` (command=set_color) - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `ligand_carbon` (command=set_color) - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `water_blue` (command=set_color) - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `oxygen_red` (command=set_color) - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `nitrogen_blue` (command=set_color) - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `sulfur_yellow` (command=set_color) - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `chlorine_green` (command=set_color) - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- loaded `d3r` (command=load)
- atoms_removed `not chain A` (command=remove)
- hidden `all` (command=hide)
- displayed `context` (command=show)
- simplified `context` (command=show)
- colored `context` (command=color) - Target `context` is colored `protein_gray`. Author confirmed: Light gray identifies the surrounding receptor context.
- configured `context` (command=set, value=0.64)
- transparency_changed `context` (command=set, value=0.64) - Target `context` has transparency `0.64`. Suggested meaning awaiting review: Transparency changes the presentation of `context`; no scientific meaning is inferred.
- created `pocket_surface` (command=create)
- displayed `pocket_surface` (command=show)
- simplified `pocket_surface` (command=show)
- colored `pocket_surface` (command=color) - Target `pocket_surface` is colored `protein_surface_gray`. Author confirmed: Pale gray identifies the pocket surface.
- configured `pocket_surface` (command=set, value=0.50)
- transparency_changed `pocket_surface` (command=set, value=0.50) - Target `pocket_surface` has transparency `0.50`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred.
- configured `pocket_surface` (command=set, value=1)
- displayed `pocket` (command=show)
- hidden `pocket and elem H` (command=hide)
- colored `pocket and elem C` (command=color) - Target `pocket and elem C` is colored `pocket_gray`. Author confirmed: Gray identifies carbon atoms in the pocket.
- configured `pocket` (command=set, value=0.085)
- configured `pocket` (command=set, value=0.35)
- transparency_changed `pocket` (command=set, value=0.35) - Target `pocket` has transparency `0.35`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket`; no scientific meaning is inferred.
- displayed `ligand` (command=show)
- configured `ligand` (command=set, value=0.25)
- configured `ligand` (command=set, value=0.0)
- transparency_changed `ligand` (command=set, value=0.0) - Target `ligand` has transparency `0.0`. Suggested meaning awaiting review: Transparency changes the presentation of `ligand`; no scientific meaning is inferred.
- colored `(ligand) and elem C` (command=color) - Target `(ligand) and elem C` is colored `ligand_carbon`. Author confirmed: Teal identifies ligand carbon atoms.
- colored `(ligand) and elem O` (command=color) - Target `(ligand) and elem O` is colored `oxygen_red`. Author confirmed: Red identifies ligand oxygen atoms.
- colored `(ligand) and elem N` (command=color) - Target `(ligand) and elem N` is colored `nitrogen_blue`. Author confirmed: Blue identifies ligand nitrogen atoms.
- colored `(ligand) and elem S` (command=color) - Target `(ligand) and elem S` is colored `sulfur_yellow`. Author confirmed: Yellow identifies ligand sulfur atoms.
- colored `(ligand) and elem CL` (command=color) - Target `(ligand) and elem CL` is colored `chlorine_green`. Author confirmed: Green identifies ligand chlorine atoms.
- displayed `asp110` (command=show)
- configured `asp110` (command=set, value=0.18)
- configured `asp110` (command=set, value=0.0)
- transparency_changed `asp110` (command=set, value=0.0) - Target `asp110` has transparency `0.0`. Suggested meaning awaiting review: Transparency changes the presentation of `asp110`; no scientific meaning is inferred.
- colored `asp110 and elem C` (command=color) - Target `asp110 and elem C` is colored `provenance_blue`. Author confirmed: Blue identifies Asp110 carbon atoms.
- colored `asp110 and elem O` (command=color) - Target `asp110 and elem O` is colored `oxygen_red`. Author confirmed: Red identifies Asp110 oxygen atoms.
- displayed `ligand and name N2` (command=show)
- displayed `asp110 and name OD2` (command=show)
- configured `ligand and name N2` (command=set, value=0.25)
- configured `asp110 and name OD2` (command=set, value=0.25)
- measurement_intent `asp110_eticlopride_proxy` (command=distance)
- colored `asp110_eticlopride_proxy` (command=color) - Target `asp110_eticlopride_proxy` is colored `retained_green`. Author confirmed: The green distance guide joins Asp110 OD2 and eticlopride N2.
- hidden `asp110_eticlopride_proxy` (command=hide)
- configured `asp110_eticlopride_proxy` (command=set, value=2.3)
- camera_oriented `ligand or pocket` (command=orient)
- camera_turned `scene` (command=turn)
- camera_turned `scene` (command=turn)
- camera_zoomed `ligand or pocket or asp110` (command=zoom)
- clipped `scene` (command=clip)
- ray_traced `scene` (command=ray)
- output_intent `renders/case04_real_3pbl_eticlopride_asp110.png` (command=png)
- output_intent `renders/case04_real_3pbl_eticlopride_asp110.pse` (command=save)
- session_terminated `session` (command=quit)

</details>

## Molecules and selections

Recorded molecules: 0; selections: 5. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.
Open **Selected regions** in the GUI to inspect the recorded selections and their source commands.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 0
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Package checks passed for `draft` mode.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; CC0-1.0 for RCSB PDB coordinate data; CC-BY-4.0 for GPCRmd dynamic 106 data and derived tables. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
