reinitialize
bg_color white
set orthoscopic, on
set field_of_view, 20
set antialias, 3
set ray_trace_mode, 0
set ray_opaque_background, off
set ray_shadows, off
set ambient, 0.20
set direct, 0.80
set spec_reflect, 0.08
set shininess, 12
set two_sided_lighting, on
set ambient_occlusion_mode, 2
set ambient_occlusion_scale, 14
set ambient_occlusion_smooth, 8
set depth_cue, on
set fog, on
set fog_start, 0.46
set cartoon_fancy_helices, on
set cartoon_sampling, 10
set stick_quality, 24
set sphere_quality, 3
set valence, on
set valence_size, 0.045
set stick_radius, 0.14
set sphere_scale, 0.28
set dash_width, 2.0
set dash_gap, 0.28
set dash_length, 0.16
set dash_round_ends, on
set label_size, 18
set_color retained_green, [0.000, 0.620, 0.451]
set_color removed_gray, [0.557, 0.596, 0.659]
set_color warning_orange, [0.835, 0.369, 0.000]
set_color provenance_blue, [0.000, 0.447, 0.698]
set_color protein_gray, [0.835, 0.878, 0.894]
set_color pocket_gray, [0.325, 0.416, 0.447]
set_color protein_surface_gray, [0.757, 0.816, 0.839]
set_color ligand_carbon, [0.090, 0.302, 0.329]
set_color water_blue, [0.337, 0.706, 0.914]
set_color oxygen_red, [0.698, 0.227, 0.180]
set_color nitrogen_blue, [0.275, 0.361, 0.612]
set_color sulfur_yellow, [0.769, 0.573, 0.000]
set_color chlorine_green, [0.176, 0.498, 0.369]
load data/structures/3PBL.pdb, d3r
remove not chain A
hide everything
select receptor, chain A and polymer.protein
select ligand, chain A and resn ETQ and resi 1200
select pocket, byres (receptor within 5.0 of ligand)
select asp110, chain A and resi 110
select context, byres (receptor within 6.5 of (ligand or asp110))
show cartoon, context
color protein_gray, context
set cartoon_transparency, 0.64, context
create pocket_surface, pocket
show surface, pocket_surface
color protein_surface_gray, pocket_surface
set transparency, 0.50, pocket_surface
set surface_quality, 1, pocket_surface
show sticks, pocket
hide sticks, pocket and elem H
color pocket_gray, pocket and elem C
set stick_radius, 0.085, pocket
set stick_transparency, 0.35, pocket
show sticks, ligand
set stick_radius, 0.25, ligand
set stick_transparency, 0.0, ligand
color ligand_carbon, (ligand) and elem C
color oxygen_red, (ligand) and elem O
color nitrogen_blue, (ligand) and elem N
color sulfur_yellow, (ligand) and elem S
color chlorine_green, (ligand) and elem CL
show sticks, asp110
set stick_radius, 0.18, asp110
set stick_transparency, 0.0, asp110
color provenance_blue, asp110 and elem C
color oxygen_red, asp110 and elem O
show spheres, ligand and name N2
show spheres, asp110 and name OD2
set sphere_scale, 0.25, ligand and name N2
set sphere_scale, 0.25, asp110 and name OD2
distance asp110_eticlopride_proxy, asp110 and name OD2, ligand and name N2
color retained_green, asp110_eticlopride_proxy
hide labels, asp110_eticlopride_proxy
set dash_width, 2.3, asp110_eticlopride_proxy
orient ligand or pocket
turn y, -20
turn x, 10
zoom ligand or pocket or asp110, 4.2
clip slab, 30
ray 2400, 1600
png renders/case04_real_3pbl_eticlopride_asp110.png, dpi=600
save renders/case04_real_3pbl_eticlopride_asp110.pse
quit
