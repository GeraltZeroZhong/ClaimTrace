# Figure 1B1 - Pocket visibility

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 1B1
- Claim: Two views locate AP5 within the adenylate kinase pocket.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/1_1_occluded_ligand.png`, `renders/1_2_buried_pocket_surface.png`
- Evidence summary: Inspect the supplied pocket views, scene scripts and 1AKE coordinates.: Both supplied views show 1AKE chain A and AP5. The surface view exposes the pocket around the ligand.
- Visual meanings: to record
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Inspect the supplied pocket views, scene scripts and 1AKE coordinates.: Both supplied views show 1AKE chain A and AP5. The surface view exposes the pocket around the ligand.

## Visual meanings

Visual meanings: awaiting author description.

## Open items and limits

- Required checks passed for `draft` export
- Additional review items: 6; see `human_review_required` in `validation_report.json`.
- Scope: Imported scene instructions preserve visual context. Viewer loading, selections, and rendered output require a replay check.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: 4 present / 2 present
- Structure/map files: 1 present
- Evidence entries: 1 recorded
- Dedicated evidence/validation files: to record
- `Figure 1B1`: Two views locate AP5 within the adenylate kinase pocket.
  Renders: `renders/1_1_occluded_ligand.png` (Rendered panel), `renders/1_2_buried_pocket_surface.png` (Rendered panel)
  Native files: `native/1_1_occluded_ligand.pml` (PyMOL scene), `native/1_2_buried_pocket_surface.pml` (PyMOL scene)
  Supporting files: `native/1_1_occluded_ligand.pml` (PyMOL scene), `native/1_2_buried_pocket_surface.pml` (PyMOL scene), `native/1_1_occluded_ligand.pse` (PyMOL session), `native/1_2_buried_pocket_surface.pse` (PyMOL session), `native/data/pdb_ap5/pdb_00001ake.cif.gz` (Structure file)

## Claims

### Figure 1B1

- Text: Two views locate AP5 within the adenylate kinase pocket.
- Type: simple_structure_view
- Figure/panel: Figure 1B1
- Linked scenes: 2
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- manual rationale
  Claim link: claim:gui:55678e2f90bc
  How it was checked: Inspect the supplied pocket views, scene scripts and 1AKE coordinates.
  Source files: `native/1_1_occluded_ligand.pml` (PyMOL scene), `native/1_2_buried_pocket_surface.pml` (PyMOL scene), `native/1_1_occluded_ligand.pse` (PyMOL session), `native/1_2_buried_pocket_surface.pse` (PyMOL session), `native/data/pdb_ap5/pdb_00001ake.cif.gz` (Structure file)
  Observation: Both supplied views show 1AKE chain A and AP5. The surface view exposes the pocket around the ligand.
  Analysis settings: Structure: PDB 1AKE, chain A; ligand: AP5. Pocket: whole residues with any atom within 4.2 angstrom of AP5.

## Uncertainty

- general: Pocket visibility depends on the representation and camera. Use the supplied PSE for the full saved view; the reduced PML records the structure and camera. Native-view replay remains pending.
## Scene files and images

- PyMOL scene: `native/1_1_occluded_ligand.pml`
- PyMOL scene: `native/1_2_buried_pocket_surface.pml`
- Rendered panel: `renders/1_1_occluded_ligand.png`
- Rendered panel: `renders/1_2_buried_pocket_surface.png`
- PyMOL session: `native/1_1_occluded_ligand.pse`
- PyMOL session: `native/1_2_buried_pocket_surface.pse`

## Reproduce the figure

ClaimTrace imports saved scene instructions. Open the scene in its original viewer to check loading, selections, and the saved view. Assess the scientific claim using the linked evidence and limitations.
Replay only native scripts you trust. Review raw or unknown commands first, and use an isolated, network-restricted viewer when provenance is uncertain.
- PyMOL scene: `native/1_1_occluded_ligand.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol 1_1_occluded_ligand.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\1_1_occluded_ligand.pml'`
- PyMOL scene: `native/1_2_buried_pocket_surface.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol 1_2_buried_pocket_surface.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\1_2_buried_pocket_surface.pml'`
- PyMOL session: open `native/1_1_occluded_ligand.pse` in a compatible local PyMOL version.
- PyMOL session: open `native/1_2_buried_pocket_surface.pse` in a compatible local PyMOL version.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Observed scene operations:
- `op:pymol:82abe2b0db3b`: loaded `source`
- `op:pymol:1aedd945a480`: created `protein`
- `op:pymol:e310396d3b0a`: created `ligand`
- `op:pymol:6a8a3b3738db`: object_deleted `source`
- `op:pymol:b890465e1e01`: atoms_removed `hydro`
- `op:pymol:6ce9bd627ac1`: camera_set `scene`
- `op:pymol:5360e4ce176c`: loaded `source`
- `op:pymol:5224196bef7f`: created `protein`
- `op:pymol:a13e92c07483`: created `ligand`
- `op:pymol:c8c17b6f40ec`: object_deleted `source`
- `op:pymol:ae22e18a3305`: atoms_removed `hydro`
- `op:pymol:7c2633e4f3c9`: camera_set `scene`

Native references needing or containing identity context:
- `native-ref:pymol:f8bd609b398c`: `source` -> data/pdb_ap5/pdb_00001ake.cif.gz
- `native-ref:pymol:2dd179b79a9e`: `source` -> data/pdb_ap5/pdb_00001ake.cif.gz

Native resource references:
- `resource:pymol:5f0274cde8d6` (relative, fixity available): `data/pdb_ap5/pdb_00001ake.cif.gz`
- `resource:pymol:a3f749e909c6` (relative, fixity available): `data/pdb_ap5/pdb_00001ake.cif.gz`

## Scene details

### scene:fbedff620034

Automatically observed native scene operations:
- loaded `source` (command=load)
- created `protein` (command=create)
- created `ligand` (command=create)
- object_deleted `source` (command=delete)
- atoms_removed `hydro` (command=remove)
- camera_set `scene` (command=set_view)
### scene:3e30dd110589

Automatically observed native scene operations:
- loaded `source` (command=load)
- created `protein` (command=create)
- created `ligand` (command=create)
- object_deleted `source` (command=delete)
- atoms_removed `hydro` (command=remove)
- camera_set `scene` (command=set_view)

</details>

## Molecules and selections

Recorded molecules: 0; selections: 0. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 0
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Package checks passed for `draft` mode.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; CC0-1.0 for RCSB PDB coordinate data. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
