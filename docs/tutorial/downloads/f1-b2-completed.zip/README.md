# Figure 1B2 - Contacts across views

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 1B2
- Claim: The AP5 pocket links a 3D proximity view to a residue contact map.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/2_1_interaction_view.png`, `renders/2_2_residue_contact_map.png`
- Evidence summary: Review the residue and contact tables alongside the supplied 3D view and contact map.: The supplied tables describe 214 residues, 36 AP5-neighbor rows, 453 unique full-protein C-alpha contact pairs and 175 contact cells in the displayed map.
- Visual meanings: to record
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Review the residue and contact tables alongside the supplied 3D view and contact map.: The supplied tables describe 214 residues, 36 AP5-neighbor rows, 453 unique full-protein C-alpha contact pairs and 175 contact cells in the displayed map.

## Visual meanings

Visual meanings: awaiting author description.

## Open items and limits

- Required checks passed for `draft` export
- Additional review items: 3; see `human_review_required` in `validation_report.json`.
- Scope: Imported scene instructions preserve visual context. Viewer loading, selections, and rendered output require a replay check.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: 2 present / 2 present
- Structure/map files: 1 present
- Evidence entries: 1 recorded
- Dedicated evidence/validation files: 3 present
- `Figure 1B2`: The AP5 pocket links a 3D proximity view to a residue contact map.
  Renders: `renders/2_1_interaction_view.png` (Rendered panel), `renders/2_2_residue_contact_map.png` (Rendered panel)
  Native files: `native/2_1_interaction_view.pml` (PyMOL scene)
  Supporting files: `evidence/2_2_contact_map_residues.csv` (Contact table), `evidence/2_2_contact_map_pairs.csv` (Contact table), `data/2_1_interaction_view_contacts.json` (Contact table), `native/data/pdb_ap5/pdb_00001ake.cif.gz` (Structure file)

## Claims

### Figure 1B2

- Text: The AP5 pocket links a 3D proximity view to a residue contact map.
- Type: simple_structure_view
- Figure/panel: Figure 1B2
- Linked scenes: 1
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- contact table
  Claim link: claim:gui:9311c0cc1da2
  How it was checked: Review the residue and contact tables alongside the supplied 3D view and contact map.
  Source files: `evidence/2_2_contact_map_residues.csv` (Contact table), `evidence/2_2_contact_map_pairs.csv` (Contact table), `data/2_1_interaction_view_contacts.json` (Contact table), `native/data/pdb_ap5/pdb_00001ake.cif.gz` (Structure file)
  Observation: The supplied tables describe 214 residues, 36 AP5-neighbor rows, 453 unique full-protein C-alpha contact pairs and 175 contact cells in the displayed map.
  Analysis settings: Protein contacts: C-alpha distance below 8 angstrom with sequence separation at least 4. Displayed rows: 36 residues within 4.2 angstrom of AP5. Ligand guide cutoff: 4 angstrom. Structure: 1AKE chain A.
  Cutoffs: distance: 8 angstrom

## Uncertainty

- general: The 175 displayed cells and 453 full-protein pairs count different selections. Distance guides show proximity. The 0.521 angstrom AP5 O1D-ARG167 NH1 pair uses B/B alternate locations and needs coordinate-level interpretation.
## Scene files and images

- PyMOL scene: `native/2_1_interaction_view.pml`
- Rendered panel: `renders/2_1_interaction_view.png`
- Rendered panel: `renders/2_2_residue_contact_map.png`
- PyMOL session: `native/2_1_interaction_view.pse`

## Reproduce the figure

ClaimTrace imports saved scene instructions. Open the scene in its original viewer to check loading, selections, and the saved view. Assess the scientific claim using the linked evidence and limitations.
Replay only native scripts you trust. Review raw or unknown commands first, and use an isolated, network-restricted viewer when provenance is uncertain.
- PyMOL scene: `native/2_1_interaction_view.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol 2_1_interaction_view.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\2_1_interaction_view.pml'`
- PyMOL session: open `native/2_1_interaction_view.pse` in a compatible local PyMOL version.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Observed scene operations:
- `op:pymol:421c61ce5ca7`: loaded `source`
- `op:pymol:a0c8ebda0dd5`: created `protein`
- `op:pymol:e50cd0e78b90`: created `ligand`
- `op:pymol:aa636745ab42`: object_deleted `source`
- `op:pymol:f130889484dd`: atoms_removed `hydro`
- `op:pymol:0195219eb1f7`: camera_set `scene`

Native references needing or containing identity context:
- `native-ref:pymol:5655d4ea81ea`: `source` -> data/pdb_ap5/pdb_00001ake.cif.gz

Native resource references:
- `resource:pymol:9443b90782ca` (relative, fixity available): `data/pdb_ap5/pdb_00001ake.cif.gz`

## Scene details

### scene:890447b0d448

Automatically observed native scene operations:
- loaded `source` (command=load)
- created `protein` (command=create)
- created `ligand` (command=create)
- object_deleted `source` (command=delete)
- atoms_removed `hydro` (command=remove)
- camera_set `scene` (command=set_view)

</details>

## Molecules and selections

Recorded molecules: 0; selections: 0. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 0
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Package checks passed for `draft` mode.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; CC0-1.0 for RCSB PDB coordinate data. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
