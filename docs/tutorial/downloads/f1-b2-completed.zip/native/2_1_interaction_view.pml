# Replay source for this panel. Run from the package root.
load data/pdb_ap5/pdb_00001ake.cif.gz, source
create protein, source and polymer.protein and chain A
create ligand, source and resn AP5 and chain A
delete source
remove hydro
set_view (0.82825762, 0.03081060, 0.55949980, -0.55393100, 0.19569105, 0.80923766, -0.08455600, -0.98018152, 0.17914954, 0.00000000, 0.00000000, -142.61358643, 21.58662415, 44.55500793, 20.07944107, 112.43763733, 172.78953552, 20.00000000)
