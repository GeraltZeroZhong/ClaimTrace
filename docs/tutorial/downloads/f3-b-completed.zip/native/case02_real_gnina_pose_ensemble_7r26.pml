reinitialize
bg_color white
set orthoscopic, on
set field_of_view, 20
set antialias, 3
set ray_trace_mode, 0
set ray_opaque_background, off
set ray_shadows, off
set ambient, 0.20
set direct, 0.80
set spec_reflect, 0.08
set shininess, 12
set two_sided_lighting, on
set ambient_occlusion_mode, 2
set ambient_occlusion_scale, 14
set ambient_occlusion_smooth, 8
set depth_cue, on
set fog, on
set fog_start, 0.46
set cartoon_fancy_helices, on
set cartoon_sampling, 10
set stick_quality, 24
set sphere_quality, 3
set valence, on
set valence_size, 0.045
set stick_radius, 0.14
set sphere_scale, 0.28
set dash_width, 2.0
set dash_gap, 0.28
set dash_length, 0.16
set dash_round_ends, on
set label_size, 18
set_color retained_green, [0.000, 0.620, 0.451]
set_color removed_gray, [0.557, 0.596, 0.659]
set_color warning_orange, [0.835, 0.369, 0.000]
set_color provenance_blue, [0.000, 0.447, 0.698]
set_color protein_gray, [0.835, 0.878, 0.894]
set_color pocket_gray, [0.325, 0.416, 0.447]
set_color protein_surface_gray, [0.757, 0.816, 0.839]
set_color ligand_carbon, [0.090, 0.302, 0.329]
set_color water_blue, [0.337, 0.706, 0.914]
set_color oxygen_red, [0.698, 0.227, 0.180]
set_color nitrogen_blue, [0.275, 0.361, 0.612]
set_color sulfur_yellow, [0.769, 0.573, 0.000]
set_color chlorine_green, [0.176, 0.498, 0.369]
load data/docking/case02_7r26_receptor/protein.pdbqt, receptor
hide everything
load data/docking/case02_7r26_poses/rank1_score1.00.sdf, pose_rank1
load data/docking/case02_7r26_poses/rank2_score1.00.sdf, pose_rank2
load data/docking/case02_7r26_poses/rank3_score0.91.sdf, pose_rank3
load data/docking/case02_7r26_poses/rank4_score0.85.sdf, pose_rank4
load data/docking/case02_7r26_poses/rank5_score0.82.sdf, pose_rank5
remove elem H
select all_poses, pose_rank1 or pose_rank2 or pose_rank3 or pose_rank4 or pose_rank5
select context, byres (receptor within 8.0 of all_poses)
select pocket, byres (receptor within 5.0 of all_poses)
show cartoon, context
color protein_gray, context
set cartoon_transparency, 0.66, context
create pocket_surface, pocket
show surface, pocket_surface
color protein_surface_gray, pocket_surface
set transparency, 0.52, pocket_surface
set surface_quality, 1, pocket_surface
show sticks, pocket
hide sticks, pocket and elem H
color pocket_gray, pocket and elem C
set stick_radius, 0.085, pocket
set stick_transparency, 0.38, pocket
show sticks, pose_rank1
color warning_orange, pose_rank1 and elem C
color oxygen_red, (pose_rank1) and elem O
color nitrogen_blue, (pose_rank1) and elem N
color sulfur_yellow, (pose_rank1) and elem S
color chlorine_green, (pose_rank1) and elem CL
set stick_radius, 0.28, pose_rank1
set stick_transparency, 0.0, pose_rank1
show sticks, pose_rank2
color retained_green, pose_rank2 and elem C
color oxygen_red, (pose_rank2) and elem O
color nitrogen_blue, (pose_rank2) and elem N
color sulfur_yellow, (pose_rank2) and elem S
color chlorine_green, (pose_rank2) and elem CL
set stick_radius, 0.28, pose_rank2
set stick_transparency, 0.0, pose_rank2
show sticks, pose_rank3
color removed_gray, pose_rank3 and elem C
color oxygen_red, (pose_rank3) and elem O
color nitrogen_blue, (pose_rank3) and elem N
color sulfur_yellow, (pose_rank3) and elem S
color chlorine_green, (pose_rank3) and elem CL
set stick_radius, 0.105, pose_rank3
set stick_transparency, 0.66, pose_rank3
show sticks, pose_rank4
color removed_gray, pose_rank4 and elem C
color oxygen_red, (pose_rank4) and elem O
color nitrogen_blue, (pose_rank4) and elem N
color sulfur_yellow, (pose_rank4) and elem S
color chlorine_green, (pose_rank4) and elem CL
set stick_radius, 0.105, pose_rank4
set stick_transparency, 0.66, pose_rank4
show sticks, pose_rank5
color removed_gray, pose_rank5 and elem C
color oxygen_red, (pose_rank5) and elem O
color nitrogen_blue, (pose_rank5) and elem N
color sulfur_yellow, (pose_rank5) and elem S
color chlorine_green, (pose_rank5) and elem CL
set stick_radius, 0.105, pose_rank5
set stick_transparency, 0.66, pose_rank5
orient all_poses
zoom all_poses or pocket, 6.0
clip slab, 22
ray 2400, 1600
png renders/case02_real_gnina_pose_ensemble_7r26.png, dpi=600
save renders/case02_real_gnina_pose_ensemble_7r26.pse
quit
