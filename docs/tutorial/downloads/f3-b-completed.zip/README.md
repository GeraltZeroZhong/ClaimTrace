# Figure 4B — Compare ranked ligand poses

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 4B
- Claim: The top two 7R26 poses share a score of 1.00 and differ in supplied reference RMSD: 4.5683 angstrom for rank 1 and 0.3736 angstrom for rank 2.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/case02_real_gnina_pose_ensemble_7r26.png`
- Evidence summary: Review the 7R26 rows in the pose-evidence table alongside the five saved poses.: The supplied 7R26 table gives ranks 1 and 2 a score of 1.00, with reference RMSDs of 4.5683 and 0.3736 angstrom. Its contact and pocket-coverage columns add separate geometric criteria.
- Visual meanings: colored on `pocket_surface`: needs review; transparency changed on `pocket_surface`: needs review
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Review the 7R26 rows in the pose-evidence table alongside the five saved poses.: The supplied 7R26 table gives ranks 1 and 2 a score of 1.00, with reference RMSDs of 4.5683 and 0.3736 angstrom. Its contact and pocket-coverage columns add separate geometric criteria.

## Visual meanings

- colored on `pocket_surface`: needs review
- transparency changed on `pocket_surface`: needs review
- colored on `pocket and elem C`: needs review
- transparency changed on `pocket`: needs review
- colored on `pose_rank1 and elem C`: needs review
- colored on `(pose_rank1) and elem O`: needs review
- colored on `(pose_rank1) and elem N`: needs review
- colored on `(pose_rank1) and elem S`: needs review
- colored on `(pose_rank1) and elem CL`: needs review
- transparency changed on `pose_rank1`: needs review
- colored on `pose_rank2 and elem C`: needs review
- colored on `(pose_rank2) and elem O`: needs review
- colored on `(pose_rank2) and elem N`: needs review
- colored on `(pose_rank2) and elem S`: needs review
- colored on `(pose_rank2) and elem CL`: needs review
- transparency changed on `pose_rank2`: needs review
- colored on `pose_rank3 and elem C`: needs review
- colored on `(pose_rank3) and elem O`: needs review
- colored on `(pose_rank3) and elem N`: needs review
- colored on `(pose_rank3) and elem S`: needs review
- colored on `(pose_rank3) and elem CL`: needs review
- transparency changed on `pose_rank3`: needs review
- colored on `pose_rank4 and elem C`: needs review
- colored on `(pose_rank4) and elem O`: needs review
- colored on `(pose_rank4) and elem N`: needs review
- colored on `(pose_rank4) and elem S`: needs review
- colored on `(pose_rank4) and elem CL`: needs review
- transparency changed on `pose_rank4`: needs review
- colored on `pose_rank5 and elem C`: needs review
- colored on `(pose_rank5) and elem O`: needs review
- colored on `(pose_rank5) and elem N`: needs review
- colored on `(pose_rank5) and elem S`: needs review
- colored on `(pose_rank5) and elem CL`: needs review
- transparency changed on `pose_rank5`: needs review

## Open items and limits

- Required checks passed for `draft` export
- Additional review items: 21; see `human_review_required` in `validation_report.json`.
- Scope: Imported scene instructions preserve visual context. Viewer loading, selections, and rendered output require a replay check.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: 2 present / 1 present
- Structure/map files: 6 present
- Evidence entries: 1 recorded
- Dedicated evidence/validation files: 1 present
- `Figure 4B`: The top two 7R26 poses share a score of 1.00 and differ in supplied reference RMSD: 4.5683 angstrom for rank 1 and 0.3736 angstrom for rank 2.
  Renders: `renders/case02_real_gnina_pose_ensemble_7r26.png` (Rendered panel)
  Native files: `native/case02_real_gnina_pose_ensemble_7r26.pml` (PyMOL scene)
  Supporting files: `data/case02_pose_evidence_augmented.csv` (Validation report), `native/data/docking/case02_7r26_receptor/protein.pdbqt` (Structure file), `native/data/docking/case02_7r26_poses/rank1_score1.00.sdf` (Structure file), `native/data/docking/case02_7r26_poses/rank2_score1.00.sdf` (Structure file), `native/data/docking/case02_7r26_poses/rank3_score0.91.sdf` (Structure file), `native/data/docking/case02_7r26_poses/rank4_score0.85.sdf` (Structure file), `native/data/docking/case02_7r26_poses/rank5_score0.82.sdf` (Structure file)

## Claims

### Figure 4B

- Text: The top two 7R26 poses share a score of 1.00 and differ in supplied reference RMSD: 4.5683 angstrom for rank 1 and 0.3736 angstrom for rank 2.
- Type: model_comparison
- Figure/panel: Figure 4B
- Linked scenes: 1
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- external validation
  Claim link: claim:gui:89b2050c6f37
  How it was checked: Review the 7R26 rows in the pose-evidence table alongside the five saved poses.
  Source files: `data/case02_pose_evidence_augmented.csv` (Validation report), `native/data/docking/case02_7r26_receptor/protein.pdbqt` (Structure file), `native/data/docking/case02_7r26_poses/rank1_score1.00.sdf` (Structure file), `native/data/docking/case02_7r26_poses/rank2_score1.00.sdf` (Structure file), `native/data/docking/case02_7r26_poses/rank3_score0.91.sdf` (Structure file), `native/data/docking/case02_7r26_poses/rank4_score0.85.sdf` (Structure file), `native/data/docking/case02_7r26_poses/rank5_score0.82.sdf` (Structure file)
  Observation: The supplied 7R26 table gives ranks 1 and 2 a score of 1.00, with reference RMSDs of 4.5683 and 0.3736 angstrom. Its contact and pocket-coverage columns add separate geometric criteria.
  Analysis settings: Complex: 7R26; displayed ranks: 1-5. Contact cutoff: 4.5 angstrom; polar-contact cutoff: 3.5 angstrom; close-contact screen: 2.2 angstrom; supplied reference-RMSD threshold: 2 angstrom.

## Uncertainty

- general: The reference RMSDs are supplied benchmark results. Independent RMSD calculation requires the reference ligand. Select the 7R26 rows; the same CSV also contains 8AQJ.
## Scene files and images

- PyMOL scene: `native/case02_real_gnina_pose_ensemble_7r26.pml`
- Rendered panel: `renders/case02_real_gnina_pose_ensemble_7r26.png`
- PyMOL session: `native/case02_real_gnina_pose_ensemble_7r26.pse`

## Reproduce the figure

ClaimTrace imports saved scene instructions. Open the scene in its original viewer to check loading, selections, and the saved view. Assess the scientific claim using the linked evidence and limitations.
Replay only native scripts you trust. Review raw or unknown commands first, and use an isolated, network-restricted viewer when provenance is uncertain.
- PyMOL scene: `native/case02_real_gnina_pose_ensemble_7r26.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol case02_real_gnina_pose_ensemble_7r26.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\case02_real_gnina_pose_ensemble_7r26.pml'`
- PyMOL session: open `native/case02_real_gnina_pose_ensemble_7r26.pse` in a compatible local PyMOL version.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Observed scene operations:
- `op:pymol:d8515a6979d5`: reinitialized `scene`
- `op:pymol:05fc71c71bad`: background_colored `scene` - Scene background is colored `white`. Tool suggestion (unconfirmed): Color visually distinguishes `scene`; no scientific meaning is inferred.
- `op:pymol:e1c1ebd2fa2d`: configured `global`
- `op:pymol:3bbac589154c`: configured `global`
- `op:pymol:e7ab88b465e8`: configured `global`
- `op:pymol:bb0afadde3bb`: configured `global`
- `op:pymol:c9adde9f714a`: configured `global`
- `op:pymol:fc51d21e2976`: configured `global`
- `op:pymol:66e54aed286e`: configured `global`
- `op:pymol:739f2ee56bb1`: configured `global`
- `op:pymol:2266734d09ef`: configured `global`
- `op:pymol:451bf20914db`: configured `global`
- `op:pymol:b4fed12462fe`: configured `global`
- `op:pymol:4167d25404ee`: configured `global`
- `op:pymol:cfab26376889`: configured `global`
- `op:pymol:4b930f861c2b`: configured `global`
- `op:pymol:34e56adc1da6`: configured `global`
- `op:pymol:b16de8192669`: configured `global`
- `op:pymol:53fa2a9b9a75`: configured `global`
- `op:pymol:4b31561ea4d7`: configured `global`
- `op:pymol:261af8e889a7`: configured `global`
- `op:pymol:7c56ab494f55`: configured `global`
- `op:pymol:65162e804eb1`: configured `global`
- `op:pymol:1b1c2724c20b`: configured `global`
- `op:pymol:bf79360732d0`: configured `global`
- `op:pymol:c92b18485029`: configured `global`
- `op:pymol:c23ffa224b77`: configured `global`
- `op:pymol:4a4fb8b6f797`: configured `global`
- `op:pymol:6352eb7e78c5`: configured `global`
- `op:pymol:ccb5a043a463`: configured `global`
- `op:pymol:86f4510ed585`: configured `global`
- `op:pymol:9373f0f2e1e4`: configured `global`
- `op:pymol:a5bc1907ec4d`: custom_color_defined `retained_green` - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:ba78eb909e63`: custom_color_defined `removed_gray` - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:b6825e322e8a`: custom_color_defined `warning_orange` - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:7301e95f7ed2`: custom_color_defined `provenance_blue` - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:743e361f4a7d`: custom_color_defined `protein_gray` - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:0a6922b3577a`: custom_color_defined `pocket_gray` - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:214364b7c6d7`: custom_color_defined `protein_surface_gray` - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:9c5712432dd5`: custom_color_defined `ligand_carbon` - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:cb4c1c9c5afa`: custom_color_defined `water_blue` - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:7072295b90bd`: custom_color_defined `oxygen_red` - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:e80dca348d80`: custom_color_defined `nitrogen_blue` - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:35e97edcd96d`: custom_color_defined `sulfur_yellow` - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:1ce52d52f03f`: custom_color_defined `chlorine_green` - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:b1ccc8321ed2`: loaded `receptor`
- `op:pymol:ca2610a23300`: hidden `all`
- `op:pymol:76c70cb8391e`: loaded `pose_rank1`
- `op:pymol:11db88e45f90`: loaded `pose_rank2`
- `op:pymol:d8eabce4f405`: loaded `pose_rank3`
- `op:pymol:0601c618aa94`: loaded `pose_rank4`
- `op:pymol:d9a304bb7890`: loaded `pose_rank5`
- `op:pymol:abbd9e09ddc2`: atoms_removed `elem H`
- `op:pymol:9fcbfa41b6f7`: displayed `context`
- `op:pymol:ac3121f4828c`: simplified `context`
- `op:pymol:afc7fb4ff6ea`: colored `context` - Target `context` is colored `protein_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `context`; no scientific meaning is inferred.
- `op:pymol:90f78942eb78`: configured `context`
- `op:pymol:f5ce51da0df4`: transparency_changed `context` - Target `context` has transparency `0.66`. Tool suggestion (unconfirmed): Transparency changes the presentation of `context`; no scientific meaning is inferred.
- `op:pymol:9abcb0a19e36`: created `pocket_surface`
- `op:pymol:b1f091b6c48c`: displayed `pocket_surface`
- `op:pymol:419daa68ad22`: simplified `pocket_surface`
- `op:pymol:7c95c8c20a44`: colored `pocket_surface` - Target `pocket_surface` is colored `protein_surface_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `pocket_surface`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:4bc3e3264708`: configured `pocket_surface`
- `op:pymol:21bed780df07`: transparency_changed `pocket_surface` - Target `pocket_surface` has transparency `0.52`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:b62a24c8d04a`: configured `pocket_surface`
- `op:pymol:4a248fc9ca0c`: displayed `pocket`
- `op:pymol:745473856295`: hidden `pocket and elem H`
- `op:pymol:8fdb585569b6`: colored `pocket and elem C` - Target `pocket and elem C` is colored `pocket_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `pocket and elem C`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:e5f1ec9a0543`: configured `pocket`
- `op:pymol:b8a7ffe0aef3`: configured `pocket`
- `op:pymol:8994bb4e9af3`: transparency_changed `pocket` - Target `pocket` has transparency `0.38`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:eee9efd91d3b`: displayed `pose_rank1`
- `op:pymol:c47c712682f0`: colored `pose_rank1 and elem C` - Target `pose_rank1 and elem C` is colored `warning_orange`. Tool suggestion (unconfirmed): Color visually distinguishes `pose_rank1 and elem C`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:e977f160b562`: colored `(pose_rank1) and elem O` - Target `(pose_rank1) and elem O` is colored `oxygen_red`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank1) and elem O`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:e694abb10a76`: colored `(pose_rank1) and elem N` - Target `(pose_rank1) and elem N` is colored `nitrogen_blue`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank1) and elem N`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:7b6c8127f862`: colored `(pose_rank1) and elem S` - Target `(pose_rank1) and elem S` is colored `sulfur_yellow`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank1) and elem S`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:82f87585bd42`: colored `(pose_rank1) and elem CL` - Target `(pose_rank1) and elem CL` is colored `chlorine_green`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank1) and elem CL`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:b119b86179ae`: configured `pose_rank1`
- `op:pymol:ae6a52d376bc`: configured `pose_rank1`
- `op:pymol:e5827009c177`: transparency_changed `pose_rank1` - Target `pose_rank1` has transparency `0.0`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pose_rank1`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:96f3e01519f2`: displayed `pose_rank2`
- `op:pymol:ad489c3da421`: colored `pose_rank2 and elem C` - Target `pose_rank2 and elem C` is colored `retained_green`. Tool suggestion (unconfirmed): Color visually distinguishes `pose_rank2 and elem C`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:ed60a16152c5`: colored `(pose_rank2) and elem O` - Target `(pose_rank2) and elem O` is colored `oxygen_red`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank2) and elem O`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:6498e12efb52`: colored `(pose_rank2) and elem N` - Target `(pose_rank2) and elem N` is colored `nitrogen_blue`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank2) and elem N`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:73309531479c`: colored `(pose_rank2) and elem S` - Target `(pose_rank2) and elem S` is colored `sulfur_yellow`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank2) and elem S`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:11bbcbca5e76`: colored `(pose_rank2) and elem CL` - Target `(pose_rank2) and elem CL` is colored `chlorine_green`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank2) and elem CL`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:21ea2ad7c52f`: configured `pose_rank2`
- `op:pymol:4260ef994b06`: configured `pose_rank2`
- `op:pymol:ee790a6105da`: transparency_changed `pose_rank2` - Target `pose_rank2` has transparency `0.0`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pose_rank2`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:5545831c20cb`: displayed `pose_rank3`
- `op:pymol:d87ceb5d9582`: colored `pose_rank3 and elem C` - Target `pose_rank3 and elem C` is colored `removed_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `pose_rank3 and elem C`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:1236a3953542`: colored `(pose_rank3) and elem O` - Target `(pose_rank3) and elem O` is colored `oxygen_red`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank3) and elem O`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:706de61ed794`: colored `(pose_rank3) and elem N` - Target `(pose_rank3) and elem N` is colored `nitrogen_blue`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank3) and elem N`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:0549a33f3a3c`: colored `(pose_rank3) and elem S` - Target `(pose_rank3) and elem S` is colored `sulfur_yellow`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank3) and elem S`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:02e493a43a8a`: colored `(pose_rank3) and elem CL` - Target `(pose_rank3) and elem CL` is colored `chlorine_green`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank3) and elem CL`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:4b01990ba59c`: configured `pose_rank3`
- `op:pymol:1325590cfaa4`: configured `pose_rank3`
- `op:pymol:6b934d504f2a`: transparency_changed `pose_rank3` - Target `pose_rank3` has transparency `0.66`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pose_rank3`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:f460391288b1`: displayed `pose_rank4`
- `op:pymol:ff21ddaba34a`: colored `pose_rank4 and elem C` - Target `pose_rank4 and elem C` is colored `removed_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `pose_rank4 and elem C`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:78aa635dafb2`: colored `(pose_rank4) and elem O` - Target `(pose_rank4) and elem O` is colored `oxygen_red`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank4) and elem O`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:fb3b8fd049dd`: colored `(pose_rank4) and elem N` - Target `(pose_rank4) and elem N` is colored `nitrogen_blue`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank4) and elem N`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:dea1e602e447`: colored `(pose_rank4) and elem S` - Target `(pose_rank4) and elem S` is colored `sulfur_yellow`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank4) and elem S`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:31b5ad57c49b`: colored `(pose_rank4) and elem CL` - Target `(pose_rank4) and elem CL` is colored `chlorine_green`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank4) and elem CL`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:a9141c200ec6`: configured `pose_rank4`
- `op:pymol:cceba40bb7d8`: configured `pose_rank4`
- `op:pymol:a7d0379e8b19`: transparency_changed `pose_rank4` - Target `pose_rank4` has transparency `0.66`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pose_rank4`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:08e43b6f2c1a`: displayed `pose_rank5`
- `op:pymol:9be4d17aa671`: colored `pose_rank5 and elem C` - Target `pose_rank5 and elem C` is colored `removed_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `pose_rank5 and elem C`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:def9777d43b1`: colored `(pose_rank5) and elem O` - Target `(pose_rank5) and elem O` is colored `oxygen_red`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank5) and elem O`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:1396bcd6908f`: colored `(pose_rank5) and elem N` - Target `(pose_rank5) and elem N` is colored `nitrogen_blue`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank5) and elem N`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:7e02825a99a2`: colored `(pose_rank5) and elem S` - Target `(pose_rank5) and elem S` is colored `sulfur_yellow`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank5) and elem S`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:6828152352e8`: colored `(pose_rank5) and elem CL` - Target `(pose_rank5) and elem CL` is colored `chlorine_green`. Tool suggestion (unconfirmed): Color visually distinguishes `(pose_rank5) and elem CL`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:5b93132e3c5d`: configured `pose_rank5`
- `op:pymol:31960522629e`: configured `pose_rank5`
- `op:pymol:a8709b2ed81b`: transparency_changed `pose_rank5` - Target `pose_rank5` has transparency `0.66`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pose_rank5`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:1c5d19f5c815`: camera_oriented `all_poses`
- `op:pymol:749a95c811c4`: camera_zoomed `all_poses or pocket`
- `op:pymol:365aa4b2784b`: clipped `scene`
- `op:pymol:a0c9084c22a3`: ray_traced `scene`
- `op:pymol:a6fdd8e5883a`: output_intent `renders/case02_real_gnina_pose_ensemble_7r26.png`
- `op:pymol:e1eb679e0c94`: output_intent `renders/case02_real_gnina_pose_ensemble_7r26.pse`
- `op:pymol:49d8e6667899`: session_terminated `session`

Native references needing or containing identity context:
- `native-ref:pymol:8976c07aca7e`: `receptor` -> data/docking/case02_7r26_receptor/protein.pdbqt
- `native-ref:pymol:78394920a63e`: `pose_rank1` -> data/docking/case02_7r26_poses/rank1_score1.00.sdf
- `native-ref:pymol:50da5b91eca5`: `pose_rank2` -> data/docking/case02_7r26_poses/rank2_score1.00.sdf
- `native-ref:pymol:00adec76c27f`: `pose_rank3` -> data/docking/case02_7r26_poses/rank3_score0.91.sdf
- `native-ref:pymol:551dadd10568`: `pose_rank4` -> data/docking/case02_7r26_poses/rank4_score0.85.sdf
- `native-ref:pymol:97753520bdf6`: `pose_rank5` -> data/docking/case02_7r26_poses/rank5_score0.82.sdf

Native resource references:
- `resource:pymol:6544e5b3659b` (relative, fixity available): `data/docking/case02_7r26_receptor/protein.pdbqt`
- `resource:pymol:afe04910393a` (relative, fixity available): `data/docking/case02_7r26_poses/rank1_score1.00.sdf`
- `resource:pymol:de8b87abcb63` (relative, fixity available): `data/docking/case02_7r26_poses/rank2_score1.00.sdf`
- `resource:pymol:21de69482c1f` (relative, fixity available): `data/docking/case02_7r26_poses/rank3_score0.91.sdf`
- `resource:pymol:bdebc35c09ae` (relative, fixity available): `data/docking/case02_7r26_poses/rank4_score0.85.sdf`
- `resource:pymol:54c5efb16e3c` (relative, fixity available): `data/docking/case02_7r26_poses/rank5_score0.82.sdf`

## Scene details

### scene:d29aa43a1cd2

Recorded view or figure settings: Source PML: orient all_poses; zoom all_poses or pocket, 6.0; clip slab, 22. Viewer replay remains pending.

Automatically observed native scene operations:
- reinitialized `scene` (command=reinitialize)
- background_colored `scene` (command=bg_color) - Scene background is colored `white`. Suggested meaning awaiting review: Color visually distinguishes `scene`; no scientific meaning is inferred.
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=20)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=0)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=0.20)
- configured `global` (command=set, value=0.80)
- configured `global` (command=set, value=0.08)
- configured `global` (command=set, value=12)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=2)
- configured `global` (command=set, value=14)
- configured `global` (command=set, value=8)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.46)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=10)
- configured `global` (command=set, value=24)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.045)
- configured `global` (command=set, value=0.14)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=2.0)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=0.16)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=18)
- custom_color_defined `retained_green` (command=set_color) - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `removed_gray` (command=set_color) - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `warning_orange` (command=set_color) - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `provenance_blue` (command=set_color) - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_gray` (command=set_color) - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `pocket_gray` (command=set_color) - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_surface_gray` (command=set_color) - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `ligand_carbon` (command=set_color) - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `water_blue` (command=set_color) - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `oxygen_red` (command=set_color) - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `nitrogen_blue` (command=set_color) - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `sulfur_yellow` (command=set_color) - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `chlorine_green` (command=set_color) - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- loaded `receptor` (command=load)
- hidden `all` (command=hide)
- loaded `pose_rank1` (command=load)
- loaded `pose_rank2` (command=load)
- loaded `pose_rank3` (command=load)
- loaded `pose_rank4` (command=load)
- loaded `pose_rank5` (command=load)
- atoms_removed `elem H` (command=remove)
- displayed `context` (command=show)
- simplified `context` (command=show)
- colored `context` (command=color) - Target `context` is colored `protein_gray`. Suggested meaning awaiting review: Color visually distinguishes `context`; no scientific meaning is inferred.
- configured `context` (command=set, value=0.66)
- transparency_changed `context` (command=set, value=0.66) - Target `context` has transparency `0.66`. Suggested meaning awaiting review: Transparency changes the presentation of `context`; no scientific meaning is inferred.
- created `pocket_surface` (command=create)
- displayed `pocket_surface` (command=show)
- simplified `pocket_surface` (command=show)
- colored `pocket_surface` (command=color) - Target `pocket_surface` is colored `protein_surface_gray`. Suggested meaning awaiting review: Color visually distinguishes `pocket_surface`; no scientific meaning is inferred.
- configured `pocket_surface` (command=set, value=0.52)
- transparency_changed `pocket_surface` (command=set, value=0.52) - Target `pocket_surface` has transparency `0.52`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred.
- configured `pocket_surface` (command=set, value=1)
- displayed `pocket` (command=show)
- hidden `pocket and elem H` (command=hide)
- colored `pocket and elem C` (command=color) - Target `pocket and elem C` is colored `pocket_gray`. Suggested meaning awaiting review: Color visually distinguishes `pocket and elem C`; no scientific meaning is inferred.
- configured `pocket` (command=set, value=0.085)
- configured `pocket` (command=set, value=0.38)
- transparency_changed `pocket` (command=set, value=0.38) - Target `pocket` has transparency `0.38`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket`; no scientific meaning is inferred.
- displayed `pose_rank1` (command=show)
- colored `pose_rank1 and elem C` (command=color) - Target `pose_rank1 and elem C` is colored `warning_orange`. Suggested meaning awaiting review: Color visually distinguishes `pose_rank1 and elem C`; no scientific meaning is inferred.
- colored `(pose_rank1) and elem O` (command=color) - Target `(pose_rank1) and elem O` is colored `oxygen_red`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank1) and elem O`; no scientific meaning is inferred.
- colored `(pose_rank1) and elem N` (command=color) - Target `(pose_rank1) and elem N` is colored `nitrogen_blue`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank1) and elem N`; no scientific meaning is inferred.
- colored `(pose_rank1) and elem S` (command=color) - Target `(pose_rank1) and elem S` is colored `sulfur_yellow`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank1) and elem S`; no scientific meaning is inferred.
- colored `(pose_rank1) and elem CL` (command=color) - Target `(pose_rank1) and elem CL` is colored `chlorine_green`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank1) and elem CL`; no scientific meaning is inferred.
- configured `pose_rank1` (command=set, value=0.28)
- configured `pose_rank1` (command=set, value=0.0)
- transparency_changed `pose_rank1` (command=set, value=0.0) - Target `pose_rank1` has transparency `0.0`. Suggested meaning awaiting review: Transparency changes the presentation of `pose_rank1`; no scientific meaning is inferred.
- displayed `pose_rank2` (command=show)
- colored `pose_rank2 and elem C` (command=color) - Target `pose_rank2 and elem C` is colored `retained_green`. Suggested meaning awaiting review: Color visually distinguishes `pose_rank2 and elem C`; no scientific meaning is inferred.
- colored `(pose_rank2) and elem O` (command=color) - Target `(pose_rank2) and elem O` is colored `oxygen_red`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank2) and elem O`; no scientific meaning is inferred.
- colored `(pose_rank2) and elem N` (command=color) - Target `(pose_rank2) and elem N` is colored `nitrogen_blue`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank2) and elem N`; no scientific meaning is inferred.
- colored `(pose_rank2) and elem S` (command=color) - Target `(pose_rank2) and elem S` is colored `sulfur_yellow`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank2) and elem S`; no scientific meaning is inferred.
- colored `(pose_rank2) and elem CL` (command=color) - Target `(pose_rank2) and elem CL` is colored `chlorine_green`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank2) and elem CL`; no scientific meaning is inferred.
- configured `pose_rank2` (command=set, value=0.28)
- configured `pose_rank2` (command=set, value=0.0)
- transparency_changed `pose_rank2` (command=set, value=0.0) - Target `pose_rank2` has transparency `0.0`. Suggested meaning awaiting review: Transparency changes the presentation of `pose_rank2`; no scientific meaning is inferred.
- displayed `pose_rank3` (command=show)
- colored `pose_rank3 and elem C` (command=color) - Target `pose_rank3 and elem C` is colored `removed_gray`. Suggested meaning awaiting review: Color visually distinguishes `pose_rank3 and elem C`; no scientific meaning is inferred.
- colored `(pose_rank3) and elem O` (command=color) - Target `(pose_rank3) and elem O` is colored `oxygen_red`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank3) and elem O`; no scientific meaning is inferred.
- colored `(pose_rank3) and elem N` (command=color) - Target `(pose_rank3) and elem N` is colored `nitrogen_blue`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank3) and elem N`; no scientific meaning is inferred.
- colored `(pose_rank3) and elem S` (command=color) - Target `(pose_rank3) and elem S` is colored `sulfur_yellow`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank3) and elem S`; no scientific meaning is inferred.
- colored `(pose_rank3) and elem CL` (command=color) - Target `(pose_rank3) and elem CL` is colored `chlorine_green`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank3) and elem CL`; no scientific meaning is inferred.
- configured `pose_rank3` (command=set, value=0.105)
- configured `pose_rank3` (command=set, value=0.66)
- transparency_changed `pose_rank3` (command=set, value=0.66) - Target `pose_rank3` has transparency `0.66`. Suggested meaning awaiting review: Transparency changes the presentation of `pose_rank3`; no scientific meaning is inferred.
- displayed `pose_rank4` (command=show)
- colored `pose_rank4 and elem C` (command=color) - Target `pose_rank4 and elem C` is colored `removed_gray`. Suggested meaning awaiting review: Color visually distinguishes `pose_rank4 and elem C`; no scientific meaning is inferred.
- colored `(pose_rank4) and elem O` (command=color) - Target `(pose_rank4) and elem O` is colored `oxygen_red`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank4) and elem O`; no scientific meaning is inferred.
- colored `(pose_rank4) and elem N` (command=color) - Target `(pose_rank4) and elem N` is colored `nitrogen_blue`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank4) and elem N`; no scientific meaning is inferred.
- colored `(pose_rank4) and elem S` (command=color) - Target `(pose_rank4) and elem S` is colored `sulfur_yellow`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank4) and elem S`; no scientific meaning is inferred.
- colored `(pose_rank4) and elem CL` (command=color) - Target `(pose_rank4) and elem CL` is colored `chlorine_green`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank4) and elem CL`; no scientific meaning is inferred.
- configured `pose_rank4` (command=set, value=0.105)
- configured `pose_rank4` (command=set, value=0.66)
- transparency_changed `pose_rank4` (command=set, value=0.66) - Target `pose_rank4` has transparency `0.66`. Suggested meaning awaiting review: Transparency changes the presentation of `pose_rank4`; no scientific meaning is inferred.
- displayed `pose_rank5` (command=show)
- colored `pose_rank5 and elem C` (command=color) - Target `pose_rank5 and elem C` is colored `removed_gray`. Suggested meaning awaiting review: Color visually distinguishes `pose_rank5 and elem C`; no scientific meaning is inferred.
- colored `(pose_rank5) and elem O` (command=color) - Target `(pose_rank5) and elem O` is colored `oxygen_red`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank5) and elem O`; no scientific meaning is inferred.
- colored `(pose_rank5) and elem N` (command=color) - Target `(pose_rank5) and elem N` is colored `nitrogen_blue`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank5) and elem N`; no scientific meaning is inferred.
- colored `(pose_rank5) and elem S` (command=color) - Target `(pose_rank5) and elem S` is colored `sulfur_yellow`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank5) and elem S`; no scientific meaning is inferred.
- colored `(pose_rank5) and elem CL` (command=color) - Target `(pose_rank5) and elem CL` is colored `chlorine_green`. Suggested meaning awaiting review: Color visually distinguishes `(pose_rank5) and elem CL`; no scientific meaning is inferred.
- configured `pose_rank5` (command=set, value=0.105)
- configured `pose_rank5` (command=set, value=0.66)
- transparency_changed `pose_rank5` (command=set, value=0.66) - Target `pose_rank5` has transparency `0.66`. Suggested meaning awaiting review: Transparency changes the presentation of `pose_rank5`; no scientific meaning is inferred.
- camera_oriented `all_poses` (command=orient)
- camera_zoomed `all_poses or pocket` (command=zoom)
- clipped `scene` (command=clip)
- ray_traced `scene` (command=ray)
- output_intent `renders/case02_real_gnina_pose_ensemble_7r26.png` (command=png)
- output_intent `renders/case02_real_gnina_pose_ensemble_7r26.pse` (command=save)
- session_terminated `session` (command=quit)

</details>

## Molecules and selections

Recorded molecules: 0; selections: 3. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.
Open **Selected regions** in the GUI to inspect the recorded selections and their source commands.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 0
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Package checks passed for `draft` mode.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; CC-BY-4.0 for Multi-Paradigm docking benchmark, Zenodo 19560204. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
