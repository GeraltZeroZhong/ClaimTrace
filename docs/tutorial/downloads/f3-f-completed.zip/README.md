# Figure 4F — Compare trajectory repeats

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 4F
- Claim: At a 4 angstrom Asp110-ligand distance threshold, the three repeats have occupancies of 0.7616, 0.9936 and 0.9996.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/case05b_publication_gpcrmd_d3r_event_summary.png`
- Evidence summary: Review the supplied distance-state, contact-state and replicate-summary tables.: The distance tables contain 7,500 frames. The three repeats satisfy the 4 angstrom condition in 1,904, 2,484 and 2,499 of 2,500 frames. Their exact occupancies are 0.7616, 0.9936 and 0.9996. The separate contact table contains 41,000 residue-frame states.
- Visual meanings: to record
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Review the supplied distance-state, contact-state and replicate-summary tables.: The distance tables contain 7,500 frames. The three repeats satisfy the 4 angstrom condition in 1,904, 2,484 and 2,499 of 2,500 frames. Their exact occupancies are 0.7616, 0.9936 and 0.9996. The separate contact table contains 41,000 residue-frame states.

## Visual meanings

Visual meanings: awaiting author description.

## Open items and limits

- Recommended: Original topology and trajectory files are needed for trajectory reproduction.
- Additional review items: 1; see `human_review_required` in `validation_report.json`.
- Scope: Reproduce static figures using their analysis sources and recorded plotting or assembly settings.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: to record / 1 present
- Structure/map files: to record
- Evidence entries: 1 recorded
- Dedicated evidence/validation files: 4 present
- `Figure 4F`: At a 4 angstrom Asp110-ligand distance threshold, the three repeats have occupancies of 0.7616, 0.9936 and 0.9996.
  Renders: `renders/case05b_publication_gpcrmd_d3r_event_summary.png` (Rendered panel)
  Supporting files: `data/d3r_eticlopride_gpcrmd_events_combined.csv` (Evidence note), `data/d3r_eticlopride_gpcrmd_summary.csv` (Evidence note), `evidence/d3r_eticlopride_residue_contact_summary.csv` (Contact table), `evidence/d3r_eticlopride_residue_contacts_combined.csv` (Contact table)

## Claims

### Figure 4F

- Text: At a 4 angstrom Asp110-ligand distance threshold, the three repeats have occupancies of 0.7616, 0.9936 and 0.9996.
- Type: trajectory_mechanism
- Figure/panel: Figure 4F
- Linked scenes: 1
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- trajectory analysis
  Claim link: claim:gui:353b97f15dff
  How it was checked: Review the supplied distance-state, contact-state and replicate-summary tables.
  Source files: `data/d3r_eticlopride_gpcrmd_events_combined.csv` (Evidence note), `data/d3r_eticlopride_gpcrmd_summary.csv` (Evidence note), `evidence/d3r_eticlopride_residue_contact_summary.csv` (Contact table), `evidence/d3r_eticlopride_residue_contacts_combined.csv` (Contact table)
  Observation: The distance tables contain 7,500 frames. The three repeats satisfy the 4 angstrom condition in 1,904, 2,484 and 2,499 of 2,500 frames. Their exact occupancies are 0.7616, 0.9936 and 0.9996. The separate contact table contains 41,000 residue-frame states.
  Analysis settings: Three repeats. Distance and RMSD: 2,500 frames per repeat at 0.2 ns intervals, 0-499.8 ns. Residue contacts: 500 frames per repeat at 1 ns intervals, 0-499 ns. Asp110-ligand distance threshold: 4 angstrom; contact cutoff: 4.5 angstrom; frame-zero pocket: 6.5 angstrom.

## Uncertainty

- general: Repeat 3 satisfies the distance condition in 2,499 of 2,500 frames; its occupancy rounds to 1.000 at three decimal places. Independent trajectory analysis requires the original topology and coordinate trajectories.
## Scene files and images

- Rendered panel: `renders/case05b_publication_gpcrmd_d3r_event_summary.png`

## Reproduce the figure

Review the linked analysis sources and recorded figure settings. Use the original analysis or figure-assembly tools to reproduce these static figures.
- Figure settings (`scene:4f6c0901aafb`): Three D3R-eticlopride repeats. Top: Asp110-ligand distance with a 4 angstrom threshold; middle: ligand RMSD, sampled every 0.2 ns. Bottom: selected residue contact states every 1 ns, green = present.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Imported scene observations: 0.

## Scene details

### scene:4f6c0901aafb

Recorded view or figure settings: Three D3R-eticlopride repeats. Top: Asp110-ligand distance with a 4 angstrom threshold; middle: ligand RMSD, sampled every 0.2 ns. Bottom: selected residue contact states every 1 ns, green = present.
Scene operations and visual meanings: to record.

</details>

## Molecules and selections

Recorded molecules: 0; selections: 0. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 1
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Required checks passed for `draft`.

Recommended:
- `CLAIM.TRAJECTORY.REQUIRED_CONTEXT`: Original topology and trajectory files are needed for trajectory reproduction.
  Edit: `/claims/0/evidence_ids`
  Next: Attach the original inputs and link them to the analysis evidence. Preserve the recorded method and sampling settings.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; CC-BY-4.0 for GPCRmd dynamic 106 data and derived tables. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
