# AlphaFold DB P69441 model_v6; B-factor stores per-residue pLDDT.
load data/alphafold_p69441/AF-P69441-F1-model_v6.cif, af_adk
show cartoon, af_adk
spectrum b, red_yellow_green_cyan_blue, af_adk, minimum=0, maximum=100
set_view (0.19406727, 0.26049492, 0.94576973, 0.57759422, 0.74892682, -0.32479763, -0.79292047, 0.60930377, -0.00511815, 0.00000000, 0.00000000, -164.99955750, 0.17571259, -0.32421875, 1.46787262, 130.08691406, 199.91220093, 20.00000000)
