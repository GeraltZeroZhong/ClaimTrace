# Figure 4A - Selecting conserved pocket waters

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 4A
- Claim: The retained-water view preserves eight selected waters around the 3UQX ligand, including six bridge proxies.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/case01_real_a1_all_waters.png`, `renders/case01_real_a2_retained_waters.png`, `renders/case01_real_a3_waters_removed.png`
- Evidence summary: Compare the three saved water views with the supplied water-selection table.: The 3UQX rows contain 14 nearby waters, eight retained waters and six bridge proxies. Across 20 structures, the supplied table contains 283 water records, 114 clusters and 132 retained records.
- Visual meanings: colored on `context`: Light gray identifies the surrounding protein context.; colored on `pocket_surface`: Pale gray identifies the pocket surface.
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Compare the three saved water views with the supplied water-selection table.: The 3UQX rows contain 14 nearby waters, eight retained waters and six bridge proxies. Across 20 structures, the supplied table contains 283 water records, 114 clusters and 132 retained records.

## Visual meanings

- colored on `context`: Light gray identifies the surrounding protein context.
- colored on `pocket_surface`: Pale gray identifies the pocket surface.
- colored on `pocket and elem C`: Gray identifies carbon atoms in the pocket.
- colored on `(ligand) and elem C`: Teal identifies ligand carbon atoms.
- colored on `(ligand) and elem O`: Red identifies ligand oxygen atoms.
- colored on `(ligand) and elem N`: Blue identifies ligand nitrogen atoms.
- colored on `(ligand) and elem S`: Yellow identifies ligand sulfur atoms.
- colored on `(ligand) and elem CL`: Green identifies ligand chlorine atoms.
- colored on `retained_waters`: Green identifies retained water molecules. Larger green spheres mark the six bridge proxies.
- colored on `bridge_proxy_*`: Green distance guides connect the displayed protein-water-ligand bridge proxies.

## Open items and limits

- Required checks passed for `draft` export
- Additional review items: 79; see `human_review_required` in `validation_report.json`.
- Scope: Imported scene instructions preserve visual context. Viewer loading, selections, and rendered output require a replay check.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: 6 present / 3 present
- Structure/map files: 1 present
- Evidence entries: 9 recorded
- Dedicated evidence/validation files: 4 present
- `Figure 4A`: The retained-water view preserves eight selected waters around the 3UQX ligand, including six bridge proxies.
  Renders: `renders/case01_real_a2_retained_waters.png` (Rendered panel)
  Native files: `native/case01_real_a2_retained_waters.pml` (PyMOL scene)
  Supporting files: `native/data/structures/3UQX.pdb` (Structure file), `data/alignment_metadata.csv` (Contact table), `data/bace1_selected_structures.csv` (Contact table), `data/water_evidence_summary.json` (Contact table), `data/water_evidence_table.csv` (Contact table)

## Claims

### Figure 4A

- Text: The retained-water view preserves eight selected waters around the 3UQX ligand, including six bridge proxies.
- Type: simple_structure_view
- Figure/panel: Figure 4A
- Linked scenes: 1
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- measurement
  Claim link: claim link pending
  How it was checked: PyMOL distance command
  Source files: `native/case01_real_a2_retained_waters.pml` (PyMOL scene)
  Observation: Distance/measurement intent observed in PyMOL script; not classified as a hydrogen bond or contact.
- measurement
  Claim link: claim link pending
  How it was checked: PyMOL distance command
  Source files: `native/case01_real_a2_retained_waters.pml` (PyMOL scene)
  Observation: Distance/measurement intent observed in PyMOL script; not classified as a hydrogen bond or contact.
- measurement
  Claim link: claim link pending
  How it was checked: PyMOL distance command
  Source files: `native/case01_real_a2_retained_waters.pml` (PyMOL scene)
  Observation: Distance/measurement intent observed in PyMOL script; not classified as a hydrogen bond or contact.
- measurement
  Claim link: claim link pending
  How it was checked: PyMOL distance command
  Source files: `native/case01_real_a2_retained_waters.pml` (PyMOL scene)
  Observation: Distance/measurement intent observed in PyMOL script; not classified as a hydrogen bond or contact.
- measurement
  Claim link: claim link pending
  How it was checked: PyMOL distance command
  Source files: `native/case01_real_a2_retained_waters.pml` (PyMOL scene)
  Observation: Distance/measurement intent observed in PyMOL script; not classified as a hydrogen bond or contact.
- measurement
  Claim link: claim link pending
  How it was checked: PyMOL distance command
  Source files: `native/case01_real_a2_retained_waters.pml` (PyMOL scene)
  Observation: Distance/measurement intent observed in PyMOL script; not classified as a hydrogen bond or contact.
- measurement
  Claim link: claim link pending
  How it was checked: PyMOL distance command
  Source files: `native/case01_real_a2_retained_waters.pml` (PyMOL scene)
  Observation: Distance/measurement intent observed in PyMOL script; not classified as a hydrogen bond or contact.
- measurement
  Claim link: claim link pending
  How it was checked: PyMOL distance command
  Source files: `native/case01_real_a2_retained_waters.pml` (PyMOL scene)
  Observation: Distance/measurement intent observed in PyMOL script; not classified as a hydrogen bond or contact.
- contact table
  Claim link: claim:gui:247a0f2d6332
  How it was checked: Compare the three saved water views with the supplied water-selection table.
  Source files: `native/data/structures/3UQX.pdb` (Structure file), `data/alignment_metadata.csv` (Contact table), `data/bace1_selected_structures.csv` (Contact table), `data/water_evidence_summary.json` (Contact table), `data/water_evidence_table.csv` (Contact table)
  Observation: The 3UQX rows contain 14 nearby waters, eight retained waters and six bridge proxies. Across 20 structures, the supplied table contains 283 water records, 114 clusters and 132 retained records.
  Analysis settings: Reference: 3UQX, chain A ligand ZPZ401. Water neighborhood: 4 angstrom; cluster radius: 1.2 angstrom; conservation fraction: at least 0.3; bridge proxy: each water-to-partner distance within 3.5 angstrom. Ensemble: 20 structures.
  Cutoffs: distance: 4 angstrom

## Uncertainty

- general: Bridge proxies use heavy-atom distances. Full ensemble realignment requires the other source structures. The supplied reference coordinates and three scenes support comparison of retained and hidden water context.
## Scene files and images

- PyMOL scene: `native/case01_real_a1_all_waters.pml`
- PyMOL scene: `native/case01_real_a2_retained_waters.pml`
- PyMOL scene: `native/case01_real_a3_waters_removed.pml`
- Rendered panel: `renders/case01_real_a1_all_waters.png`
- Rendered panel: `renders/case01_real_a2_retained_waters.png`
- Rendered panel: `renders/case01_real_a3_waters_removed.png`
- PyMOL session: `native/case01_real_a1_all_waters.pse`
- PyMOL session: `native/case01_real_a2_retained_waters.pse`
- PyMOL session: `native/case01_real_a3_waters_removed.pse`

## Reproduce the figure

ClaimTrace imports saved scene instructions. Open the scene in its original viewer to check loading, selections, and the saved view. Assess the scientific claim using the linked evidence and limitations.
Replay only native scripts you trust. Review raw or unknown commands first, and use an isolated, network-restricted viewer when provenance is uncertain.
- PyMOL scene: `native/case01_real_a1_all_waters.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol case01_real_a1_all_waters.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\case01_real_a1_all_waters.pml'`
- PyMOL scene: `native/case01_real_a2_retained_waters.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol case01_real_a2_retained_waters.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\case01_real_a2_retained_waters.pml'`
- PyMOL scene: `native/case01_real_a3_waters_removed.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol case01_real_a3_waters_removed.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\case01_real_a3_waters_removed.pml'`
- PyMOL session: open `native/case01_real_a1_all_waters.pse` in a compatible local PyMOL version.
- PyMOL session: open `native/case01_real_a2_retained_waters.pse` in a compatible local PyMOL version.
- PyMOL session: open `native/case01_real_a3_waters_removed.pse` in a compatible local PyMOL version.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Observed scene operations:
- `op:pymol:7764eec86e51`: reinitialized `scene`
- `op:pymol:16495c26311d`: background_colored `scene` - Scene background is colored `white`. Tool suggestion (unconfirmed): Color visually distinguishes `scene`; no scientific meaning is inferred.
- `op:pymol:1a443c51f174`: configured `global`
- `op:pymol:05d664429273`: configured `global`
- `op:pymol:43f22fe957ee`: configured `global`
- `op:pymol:e89112249743`: configured `global`
- `op:pymol:55904a52568a`: configured `global`
- `op:pymol:ee445794b4ca`: configured `global`
- `op:pymol:6d21b4560fa6`: configured `global`
- `op:pymol:3ffadbf37ed8`: configured `global`
- `op:pymol:0615eb4ef47e`: configured `global`
- `op:pymol:e6b03fb410a4`: configured `global`
- `op:pymol:e5057c501beb`: configured `global`
- `op:pymol:7fa066365cdc`: configured `global`
- `op:pymol:e15916a73553`: configured `global`
- `op:pymol:5f8b39ec35fb`: configured `global`
- `op:pymol:4d604bce3c02`: configured `global`
- `op:pymol:5c6cde27655d`: configured `global`
- `op:pymol:9682a99a1fab`: configured `global`
- `op:pymol:038f8e8a2ab1`: configured `global`
- `op:pymol:bbc955055f7a`: configured `global`
- `op:pymol:ba665ce77008`: configured `global`
- `op:pymol:f29e0f628da0`: configured `global`
- `op:pymol:5534486179ba`: configured `global`
- `op:pymol:023089489023`: configured `global`
- `op:pymol:e4e6d605c3c8`: configured `global`
- `op:pymol:194bd914cbaa`: configured `global`
- `op:pymol:ea65415fb9e1`: configured `global`
- `op:pymol:6bb2f8c41cbc`: configured `global`
- `op:pymol:f20299d5512e`: configured `global`
- `op:pymol:3f0ffb45916d`: configured `global`
- `op:pymol:96aef2e77212`: configured `global`
- `op:pymol:bf11f3b486b3`: custom_color_defined `retained_green` - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:8d7cdc9f0d5c`: custom_color_defined `removed_gray` - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:5cc76cecf219`: custom_color_defined `warning_orange` - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:d3336e8825a1`: custom_color_defined `provenance_blue` - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:e825d9073e7b`: custom_color_defined `protein_gray` - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:7fd4e9f66ffe`: custom_color_defined `pocket_gray` - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:7263b5f914bb`: custom_color_defined `protein_surface_gray` - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:e1771816bb05`: custom_color_defined `ligand_carbon` - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:c9a2c70f9966`: custom_color_defined `water_blue` - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:2e01d41f947d`: custom_color_defined `oxygen_red` - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:bc8284c44eec`: custom_color_defined `nitrogen_blue` - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:a531f8448146`: custom_color_defined `sulfur_yellow` - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:fb3bb093138c`: custom_color_defined `chlorine_green` - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:b1cd42c22927`: loaded `structure`
- `op:pymol:a3005e2ea97f`: atoms_removed `not (polymer.protein or (resn ZPZ and chain A and resi 401) or resn HOH)`
- `op:pymol:67fe8053aea7`: hidden `all`
- `op:pymol:48f5dd2e2d9d`: displayed `context`
- `op:pymol:104d82b3f17b`: simplified `context`
- `op:pymol:a7e561378dff`: colored `context` - Target `context` is colored `protein_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `context`; no scientific meaning is inferred.
- `op:pymol:8773c8ac6c0a`: configured `context`
- `op:pymol:2d98e5133807`: transparency_changed `context` - Target `context` has transparency `0.64`. Tool suggestion (unconfirmed): Transparency changes the presentation of `context`; no scientific meaning is inferred.
- `op:pymol:fc828bc682fe`: created `pocket_surface`
- `op:pymol:6edbfb717b78`: displayed `pocket_surface`
- `op:pymol:dcdc64b53401`: simplified `pocket_surface`
- `op:pymol:2b4b9338a8c2`: colored `pocket_surface` - Target `pocket_surface` is colored `protein_surface_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `pocket_surface`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:c97da9379f91`: configured `pocket_surface`
- `op:pymol:10879b9f6ec4`: transparency_changed `pocket_surface` - Target `pocket_surface` has transparency `0.50`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:0446093daa41`: configured `pocket_surface`
- `op:pymol:2d1ca08b6be2`: displayed `pocket`
- `op:pymol:ceff3fe243b3`: hidden `pocket and elem H`
- `op:pymol:9efe679443a1`: colored `pocket and elem C` - Target `pocket and elem C` is colored `pocket_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `pocket and elem C`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:5f65f5d8be3b`: configured `pocket`
- `op:pymol:80e3311df31d`: configured `pocket`
- `op:pymol:67d9f4010332`: transparency_changed `pocket` - Target `pocket` has transparency `0.34`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:f1a19863a14c`: displayed `ligand`
- `op:pymol:e67f5f42051c`: configured `ligand`
- `op:pymol:4d618b5504bd`: configured `ligand`
- `op:pymol:da3b1f51f36a`: transparency_changed `ligand` - Target `ligand` has transparency `0.0`. Tool suggestion (unconfirmed): Transparency changes the presentation of `ligand`; no scientific meaning is inferred.
- `op:pymol:28f1dd7550ce`: colored `(ligand) and elem C` - Target `(ligand) and elem C` is colored `ligand_carbon`. Tool suggestion (unconfirmed): Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- `op:pymol:f1d31ac54e24`: colored `(ligand) and elem O` - Target `(ligand) and elem O` is colored `oxygen_red`. Tool suggestion (unconfirmed): Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- `op:pymol:c453e49f93be`: colored `(ligand) and elem N` - Target `(ligand) and elem N` is colored `nitrogen_blue`. Tool suggestion (unconfirmed): Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- `op:pymol:5ca5378ac5b5`: colored `(ligand) and elem S` - Target `(ligand) and elem S` is colored `sulfur_yellow`. Tool suggestion (unconfirmed): Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- `op:pymol:1ae7d367f08d`: colored `(ligand) and elem CL` - Target `(ligand) and elem CL` is colored `chlorine_green`. Tool suggestion (unconfirmed): Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- `op:pymol:49c9c62fa9df`: displayed `selected_waters`
- `op:pymol:45814f6a5f7f`: configured `selected_waters`
- `op:pymol:8fab59d658dd`: colored `selected_waters` - Target `selected_waters` is colored `water_blue`. Tool suggestion (unconfirmed): Color visually distinguishes `selected_waters`; no scientific meaning is inferred.
- `op:pymol:e79b53feab2b`: configured `selected_waters`
- `op:pymol:0305be913748`: transparency_changed `selected_waters` - Target `selected_waters` has transparency `0.64`. Tool suggestion (unconfirmed): Transparency changes the presentation of `selected_waters`; no scientific meaning is inferred.
- `op:pymol:155f816fcb33`: displayed `retained_waters`
- `op:pymol:613f1cba6445`: configured `retained_waters`
- `op:pymol:2640dab309ba`: colored `retained_waters` - Target `retained_waters` is colored `retained_green`. Tool suggestion (unconfirmed): Color visually distinguishes `retained_waters`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:725a459b0382`: configured `retained_waters`
- `op:pymol:d2ff92138776`: transparency_changed `retained_waters` - Target `retained_waters` has transparency `0.08`. Tool suggestion (unconfirmed): Transparency changes the presentation of `retained_waters`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:1c2594b5bd85`: camera_oriented `ligand or pocket`
- `op:pymol:b0034fc8f6fa`: camera_turned `scene`
- `op:pymol:ad60f4b70777`: camera_turned `scene`
- `op:pymol:5627fcff7ef4`: camera_zoomed `ligand or pocket`
- `op:pymol:dfbc98ed62ec`: clipped `scene`
- `op:pymol:0f66fa69c3a3`: ray_traced `scene`
- `op:pymol:c9d232aef573`: output_intent `renders/case01_real_a1_all_waters.png`
- `op:pymol:47f5852aa80b`: output_intent `renders/case01_real_a1_all_waters.pse`
- `op:pymol:0565c3087e62`: session_terminated `session`
- `op:pymol:6309552a5923`: reinitialized `scene`
- `op:pymol:da9f3589d0bc`: background_colored `scene` - Scene background is colored `white`. Tool suggestion (unconfirmed): Color visually distinguishes `scene`; no scientific meaning is inferred.
- `op:pymol:04d961152821`: configured `global`
- `op:pymol:a72aee84e09c`: configured `global`
- `op:pymol:06d3b20729e7`: configured `global`
- `op:pymol:e073c7532f4f`: configured `global`
- `op:pymol:0a8a5428a722`: configured `global`
- `op:pymol:caf9cd3d0a42`: configured `global`
- `op:pymol:4e15f32fb0ce`: configured `global`
- `op:pymol:e8de1aea2dde`: configured `global`
- `op:pymol:d1f7523fedf0`: configured `global`
- `op:pymol:9db0b915856b`: configured `global`
- `op:pymol:3ad5ae6026c9`: configured `global`
- `op:pymol:6b51d2fee120`: configured `global`
- `op:pymol:7d1558fa5779`: configured `global`
- `op:pymol:61ee656fb31c`: configured `global`
- `op:pymol:b369178684da`: configured `global`
- `op:pymol:ca5d97f08fb5`: configured `global`
- `op:pymol:c9056d771765`: configured `global`
- `op:pymol:004f0d44fe4c`: configured `global`
- `op:pymol:601c9cf63fa7`: configured `global`
- `op:pymol:23e61cf3076f`: configured `global`
- `op:pymol:71d9fe1f229a`: configured `global`
- `op:pymol:42e9d49c962d`: configured `global`
- `op:pymol:43f84a1e82ea`: configured `global`
- `op:pymol:985a2398f075`: configured `global`
- `op:pymol:54cc502997a0`: configured `global`
- `op:pymol:682924b99c2f`: configured `global`
- `op:pymol:439ae65b0bf9`: configured `global`
- `op:pymol:bb9c5adcad6f`: configured `global`
- `op:pymol:cc106088dea7`: configured `global`
- `op:pymol:5ae0efd9e609`: configured `global`
- `op:pymol:6f7f35cd377d`: custom_color_defined `retained_green` - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:5a8ed82d5d3e`: custom_color_defined `removed_gray` - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:d096bed5be0c`: custom_color_defined `warning_orange` - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:7133a68554c6`: custom_color_defined `provenance_blue` - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:106983e82cba`: custom_color_defined `protein_gray` - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:9743654a6e00`: custom_color_defined `pocket_gray` - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:d88b3fabc045`: custom_color_defined `protein_surface_gray` - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:e8e7b89634b9`: custom_color_defined `ligand_carbon` - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:e79b09adb43c`: custom_color_defined `water_blue` - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:9f0d7e78b37e`: custom_color_defined `oxygen_red` - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:57b976a83f41`: custom_color_defined `nitrogen_blue` - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:c4c818edf5e9`: custom_color_defined `sulfur_yellow` - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:9afa90a4e45f`: custom_color_defined `chlorine_green` - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:f8b02fb4b4cf`: loaded `structure`
- `op:pymol:55bc68b1bf20`: atoms_removed `not (polymer.protein or (resn ZPZ and chain A and resi 401) or resn HOH)`
- `op:pymol:47431ea69717`: hidden `all`
- `op:pymol:a6c3ac4b0b93`: displayed `context`
- `op:pymol:4c9fdcc3428b`: simplified `context`
- `op:pymol:808481ca9814`: colored `context` - Target `context` is colored `protein_gray`. Author confirmed: Light gray identifies the surrounding protein context.
- `op:pymol:c4f9b7549525`: configured `context`
- `op:pymol:674d71f8f150`: transparency_changed `context` - Target `context` has transparency `0.64`. Tool suggestion (unconfirmed): Transparency changes the presentation of `context`; no scientific meaning is inferred.
- `op:pymol:9c31f065e17d`: created `pocket_surface`
- `op:pymol:9d75a5490fb7`: displayed `pocket_surface`
- `op:pymol:562b92f3d333`: simplified `pocket_surface`
- `op:pymol:149a99421b74`: colored `pocket_surface` - Target `pocket_surface` is colored `protein_surface_gray`. Author confirmed: Pale gray identifies the pocket surface.
- `op:pymol:4a55ebd6f551`: configured `pocket_surface`
- `op:pymol:09c6141895ac`: transparency_changed `pocket_surface` - Target `pocket_surface` has transparency `0.50`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:fc26f454f145`: configured `pocket_surface`
- `op:pymol:77c18c9b4149`: displayed `pocket`
- `op:pymol:c4e551aae070`: hidden `pocket and elem H`
- `op:pymol:f83fb16acc3e`: colored `pocket and elem C` - Target `pocket and elem C` is colored `pocket_gray`. Author confirmed: Gray identifies carbon atoms in the pocket.
- `op:pymol:97fda8450285`: configured `pocket`
- `op:pymol:0697d7461b53`: configured `pocket`
- `op:pymol:79f4c5ecfe10`: transparency_changed `pocket` - Target `pocket` has transparency `0.34`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:ac01a9493368`: displayed `ligand`
- `op:pymol:2278ba81c67d`: configured `ligand`
- `op:pymol:b4ec99173f93`: configured `ligand`
- `op:pymol:96f41a3e8da0`: transparency_changed `ligand` - Target `ligand` has transparency `0.0`. Tool suggestion (unconfirmed): Transparency changes the presentation of `ligand`; no scientific meaning is inferred.
- `op:pymol:f3b6f48c991b`: colored `(ligand) and elem C` - Target `(ligand) and elem C` is colored `ligand_carbon`. Author confirmed: Teal identifies ligand carbon atoms.
- `op:pymol:fdf69acfc732`: colored `(ligand) and elem O` - Target `(ligand) and elem O` is colored `oxygen_red`. Author confirmed: Red identifies ligand oxygen atoms.
- `op:pymol:2aecd39fed3f`: colored `(ligand) and elem N` - Target `(ligand) and elem N` is colored `nitrogen_blue`. Author confirmed: Blue identifies ligand nitrogen atoms.
- `op:pymol:b3e41ee8ba15`: colored `(ligand) and elem S` - Target `(ligand) and elem S` is colored `sulfur_yellow`. Author confirmed: Yellow identifies ligand sulfur atoms.
- `op:pymol:fcfb7d4df875`: colored `(ligand) and elem CL` - Target `(ligand) and elem CL` is colored `chlorine_green`. Author confirmed: Green identifies ligand chlorine atoms.
- `op:pymol:36a39bd07ae3`: displayed `retained_waters`
- `op:pymol:c85ca0725b1b`: configured `retained_waters`
- `op:pymol:5abfeca46769`: colored `retained_waters` - Target `retained_waters` is colored `retained_green`. Author confirmed: Green identifies retained water molecules. Larger green spheres mark the six bridge proxies.
- `op:pymol:d83004351a5e`: configured `retained_waters`
- `op:pymol:e2eb37e6cea3`: transparency_changed `retained_waters` - Target `retained_waters` has transparency `0.04`. Tool suggestion (unconfirmed): Transparency changes the presentation of `retained_waters`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:c00bb50af53a`: displayed `bridge_waters`
- `op:pymol:01198c2f052f`: configured `bridge_waters`
- `op:pymol:e3aa0a524d6e`: configured `bridge_waters`
- `op:pymol:ea1c675ce075`: transparency_changed `bridge_waters` - Target `bridge_waters` has transparency `0.00`. Tool suggestion (unconfirmed): Transparency changes the presentation of `bridge_waters`; no scientific meaning is inferred.
- `op:pymol:86cb27de47bb`: measurement_intent `bridge_proxy_p1`
- `op:pymol:8e4ccdf97960`: measurement_intent `bridge_proxy_l1`
- `op:pymol:50665779b411`: measurement_intent `bridge_proxy_p2`
- `op:pymol:a1bd8983cd6a`: measurement_intent `bridge_proxy_l2`
- `op:pymol:f79ac8caaa29`: measurement_intent `bridge_proxy_p3`
- `op:pymol:9a6d101de5ae`: measurement_intent `bridge_proxy_l3`
- `op:pymol:ef695db7e703`: measurement_intent `bridge_proxy_p4`
- `op:pymol:ce6450553576`: measurement_intent `bridge_proxy_l4`
- `op:pymol:2b83b939e52c`: colored `bridge_proxy_*` - Target `bridge_proxy_*` is colored `retained_green`. Author confirmed: Green distance guides connect the displayed protein-water-ligand bridge proxies.
- `op:pymol:9fb50314238a`: hidden `bridge_proxy_*`
- `op:pymol:942f7500a9a9`: camera_oriented `ligand or pocket`
- `op:pymol:e3265baf9d6f`: camera_turned `scene`
- `op:pymol:06e697a987c7`: camera_turned `scene`
- `op:pymol:347ad8739296`: camera_zoomed `ligand or pocket`
- `op:pymol:f96b91318c84`: clipped `scene`
- `op:pymol:ffd66bf174c4`: ray_traced `scene`
- `op:pymol:05e62c181e02`: output_intent `renders/case01_real_a2_retained_waters.png`
- `op:pymol:9d3fc71e82e5`: output_intent `renders/case01_real_a2_retained_waters.pse`
- `op:pymol:b933cc28cb8b`: session_terminated `session`
- `op:pymol:eeced245bc0e`: reinitialized `scene`
- `op:pymol:4ca2da1c67cb`: background_colored `scene` - Scene background is colored `white`. Tool suggestion (unconfirmed): Color visually distinguishes `scene`; no scientific meaning is inferred.
- `op:pymol:4755a2e3d4ae`: configured `global`
- `op:pymol:99e3669b18b4`: configured `global`
- `op:pymol:5a38a6628a5c`: configured `global`
- `op:pymol:a493b7c6f14f`: configured `global`
- `op:pymol:cfb0b2e7abfc`: configured `global`
- `op:pymol:8b322fc14a12`: configured `global`
- `op:pymol:ba311a182cc8`: configured `global`
- `op:pymol:c2785c4db6b1`: configured `global`
- `op:pymol:ae027e460221`: configured `global`
- `op:pymol:c12f077eafec`: configured `global`
- `op:pymol:20e21b498ec7`: configured `global`
- `op:pymol:8d144cb9ed34`: configured `global`
- `op:pymol:cba0d3a56f78`: configured `global`
- `op:pymol:51f0c7affc78`: configured `global`
- `op:pymol:ceef28e835e6`: configured `global`
- `op:pymol:906ad356c5d1`: configured `global`
- `op:pymol:ef42fded452c`: configured `global`
- `op:pymol:77c87b7401bb`: configured `global`
- `op:pymol:3ee2a8c652d8`: configured `global`
- `op:pymol:fea7040acc9b`: configured `global`
- `op:pymol:13d4728d3547`: configured `global`
- `op:pymol:47ed24857e60`: configured `global`
- `op:pymol:24c8e774f2ac`: configured `global`
- `op:pymol:e9ccf4cf4eef`: configured `global`
- `op:pymol:f035150dd24c`: configured `global`
- `op:pymol:2ca278cf4ff5`: configured `global`
- `op:pymol:e321c1842eed`: configured `global`
- `op:pymol:d7f8b4cfc868`: configured `global`
- `op:pymol:31d69e3e0d53`: configured `global`
- `op:pymol:b64107c490cd`: configured `global`
- `op:pymol:eff2640805be`: custom_color_defined `retained_green` - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:17bae6c72e05`: custom_color_defined `removed_gray` - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:7cbbbee66f0e`: custom_color_defined `warning_orange` - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:4ea21de894ae`: custom_color_defined `provenance_blue` - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:c252cad3b2e5`: custom_color_defined `protein_gray` - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:1ad35545a35c`: custom_color_defined `pocket_gray` - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:6bb5616cea42`: custom_color_defined `protein_surface_gray` - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:222f73f66166`: custom_color_defined `ligand_carbon` - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:b3cc620cd549`: custom_color_defined `water_blue` - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:5df6ee109118`: custom_color_defined `oxygen_red` - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:f2e2562f9c39`: custom_color_defined `nitrogen_blue` - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:9d2a8ae16e24`: custom_color_defined `sulfur_yellow` - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:9e0e0336e256`: custom_color_defined `chlorine_green` - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Tool suggestion (unconfirmed): A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- `op:pymol:af212508afce`: loaded `structure`
- `op:pymol:dd4e27cff709`: atoms_removed `not (polymer.protein or (resn ZPZ and chain A and resi 401) or resn HOH)`
- `op:pymol:9da2f8513cab`: hidden `all`
- `op:pymol:23a45ffe6f17`: displayed `context`
- `op:pymol:b32d22e4eb13`: simplified `context`
- `op:pymol:f78bc3eca3b6`: colored `context` - Target `context` is colored `protein_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `context`; no scientific meaning is inferred.
- `op:pymol:7a1ee4cecbe3`: configured `context`
- `op:pymol:c59711a578fc`: transparency_changed `context` - Target `context` has transparency `0.64`. Tool suggestion (unconfirmed): Transparency changes the presentation of `context`; no scientific meaning is inferred.
- `op:pymol:9c162a69b3f7`: created `pocket_surface`
- `op:pymol:61567f1442ae`: displayed `pocket_surface`
- `op:pymol:5e3c00fa5ded`: simplified `pocket_surface`
- `op:pymol:dd6753bd5287`: colored `pocket_surface` - Target `pocket_surface` is colored `protein_surface_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `pocket_surface`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:6fec1b573689`: configured `pocket_surface`
- `op:pymol:f927343a79ac`: transparency_changed `pocket_surface` - Target `pocket_surface` has transparency `0.50`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:9950cd2291c1`: configured `pocket_surface`
- `op:pymol:ccd4d16af912`: displayed `pocket`
- `op:pymol:f81f81aad7ad`: hidden `pocket and elem H`
- `op:pymol:2c27a526ccf5`: colored `pocket and elem C` - Target `pocket and elem C` is colored `pocket_gray`. Tool suggestion (unconfirmed): Color visually distinguishes `pocket and elem C`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:f176f9e0852a`: configured `pocket`
- `op:pymol:fd4cd783cd88`: configured `pocket`
- `op:pymol:cce95e1d2e59`: transparency_changed `pocket` - Target `pocket` has transparency `0.34`. Tool suggestion (unconfirmed): Transparency changes the presentation of `pocket`; no scientific meaning is inferred. Confirmation needed.
- `op:pymol:1d9b1f486496`: displayed `ligand`
- `op:pymol:18186219da22`: configured `ligand`
- `op:pymol:00cfd52264e4`: configured `ligand`
- `op:pymol:744199d961a7`: transparency_changed `ligand` - Target `ligand` has transparency `0.0`. Tool suggestion (unconfirmed): Transparency changes the presentation of `ligand`; no scientific meaning is inferred.
- `op:pymol:209650163f2c`: colored `(ligand) and elem C` - Target `(ligand) and elem C` is colored `ligand_carbon`. Tool suggestion (unconfirmed): Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- `op:pymol:586996825eb2`: colored `(ligand) and elem O` - Target `(ligand) and elem O` is colored `oxygen_red`. Tool suggestion (unconfirmed): Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- `op:pymol:f27e455a35c1`: colored `(ligand) and elem N` - Target `(ligand) and elem N` is colored `nitrogen_blue`. Tool suggestion (unconfirmed): Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- `op:pymol:fa437a39ce6a`: colored `(ligand) and elem S` - Target `(ligand) and elem S` is colored `sulfur_yellow`. Tool suggestion (unconfirmed): Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- `op:pymol:c2388c2fdb17`: colored `(ligand) and elem CL` - Target `(ligand) and elem CL` is colored `chlorine_green`. Tool suggestion (unconfirmed): Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- `op:pymol:71a4a3acbff6`: hidden `resn HOH`
- `op:pymol:dfec5210c277`: camera_oriented `ligand or pocket`
- `op:pymol:0f07c4eb3daa`: camera_turned `scene`
- `op:pymol:4b84d7a65e20`: camera_turned `scene`
- `op:pymol:55ff02f44701`: camera_zoomed `ligand or pocket`
- `op:pymol:7952b03736bd`: clipped `scene`
- `op:pymol:72860dcfa701`: ray_traced `scene`
- `op:pymol:824939d525f0`: output_intent `renders/case01_real_a3_waters_removed.png`
- `op:pymol:87871a850580`: output_intent `renders/case01_real_a3_waters_removed.pse`
- `op:pymol:a15c45b12950`: session_terminated `session`

Author-reviewed operation meanings and remaining suggestions:
- `op:pymol:808481ca9814`: user_confirmed_meaning; author confirmed: Light gray identifies the surrounding protein context.
- `op:pymol:149a99421b74`: user_confirmed_meaning; author confirmed: Pale gray identifies the pocket surface.
- `op:pymol:f83fb16acc3e`: user_confirmed_meaning; author confirmed: Gray identifies carbon atoms in the pocket.
- `op:pymol:f3b6f48c991b`: user_confirmed_meaning; author confirmed: Teal identifies ligand carbon atoms.
- `op:pymol:fdf69acfc732`: user_confirmed_meaning; author confirmed: Red identifies ligand oxygen atoms.
- `op:pymol:2aecd39fed3f`: user_confirmed_meaning; author confirmed: Blue identifies ligand nitrogen atoms.
- `op:pymol:b3e41ee8ba15`: user_confirmed_meaning; author confirmed: Yellow identifies ligand sulfur atoms.
- `op:pymol:fcfb7d4df875`: user_confirmed_meaning; author confirmed: Green identifies ligand chlorine atoms.
- `op:pymol:5abfeca46769`: user_confirmed_meaning; author confirmed: Green identifies retained water molecules. Larger green spheres mark the six bridge proxies.
- `op:pymol:2b83b939e52c`: user_confirmed_meaning; author confirmed: Green distance guides connect the displayed protein-water-ligand bridge proxies.

Native references needing or containing identity context:
- `native-ref:pymol:5b7e8caa7d08`: `structure` -> data/structures/3UQX.pdb
- `native-ref:pymol:f693ff3c9874`: `structure` -> data/structures/3UQX.pdb
- `native-ref:pymol:e057f47207f0`: `structure` -> data/structures/3UQX.pdb

Native resource references:
- `resource:pymol:f72f1fa3b164` (relative, fixity available): `data/structures/3UQX.pdb`
- `resource:pymol:8680c465f8dc` (relative, fixity available): `data/structures/3UQX.pdb`
- `resource:pymol:df51be96d2af` (relative, fixity available): `data/structures/3UQX.pdb`

## Scene details

### scene:4b9959b84614

Automatically observed native scene operations:
- reinitialized `scene` (command=reinitialize)
- background_colored `scene` (command=bg_color) - Scene background is colored `white`. Suggested meaning awaiting review: Color visually distinguishes `scene`; no scientific meaning is inferred.
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=20)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=0)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=0.20)
- configured `global` (command=set, value=0.80)
- configured `global` (command=set, value=0.08)
- configured `global` (command=set, value=12)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=2)
- configured `global` (command=set, value=14)
- configured `global` (command=set, value=8)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.46)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=10)
- configured `global` (command=set, value=24)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.045)
- configured `global` (command=set, value=0.14)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=2.0)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=0.16)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=18)
- custom_color_defined `retained_green` (command=set_color) - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `removed_gray` (command=set_color) - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `warning_orange` (command=set_color) - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `provenance_blue` (command=set_color) - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_gray` (command=set_color) - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `pocket_gray` (command=set_color) - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_surface_gray` (command=set_color) - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `ligand_carbon` (command=set_color) - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `water_blue` (command=set_color) - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `oxygen_red` (command=set_color) - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `nitrogen_blue` (command=set_color) - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `sulfur_yellow` (command=set_color) - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `chlorine_green` (command=set_color) - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- loaded `structure` (command=load)
- atoms_removed `not (polymer.protein or (resn ZPZ and chain A and resi 401) or resn HOH)` (command=remove)
- hidden `all` (command=hide)
- displayed `context` (command=show)
- simplified `context` (command=show)
- colored `context` (command=color) - Target `context` is colored `protein_gray`. Suggested meaning awaiting review: Color visually distinguishes `context`; no scientific meaning is inferred.
- configured `context` (command=set, value=0.64)
- transparency_changed `context` (command=set, value=0.64) - Target `context` has transparency `0.64`. Suggested meaning awaiting review: Transparency changes the presentation of `context`; no scientific meaning is inferred.
- created `pocket_surface` (command=create)
- displayed `pocket_surface` (command=show)
- simplified `pocket_surface` (command=show)
- colored `pocket_surface` (command=color) - Target `pocket_surface` is colored `protein_surface_gray`. Suggested meaning awaiting review: Color visually distinguishes `pocket_surface`; no scientific meaning is inferred.
- configured `pocket_surface` (command=set, value=0.50)
- transparency_changed `pocket_surface` (command=set, value=0.50) - Target `pocket_surface` has transparency `0.50`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred.
- configured `pocket_surface` (command=set, value=1)
- displayed `pocket` (command=show)
- hidden `pocket and elem H` (command=hide)
- colored `pocket and elem C` (command=color) - Target `pocket and elem C` is colored `pocket_gray`. Suggested meaning awaiting review: Color visually distinguishes `pocket and elem C`; no scientific meaning is inferred.
- configured `pocket` (command=set, value=0.085)
- configured `pocket` (command=set, value=0.34)
- transparency_changed `pocket` (command=set, value=0.34) - Target `pocket` has transparency `0.34`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket`; no scientific meaning is inferred.
- displayed `ligand` (command=show)
- configured `ligand` (command=set, value=0.25)
- configured `ligand` (command=set, value=0.0)
- transparency_changed `ligand` (command=set, value=0.0) - Target `ligand` has transparency `0.0`. Suggested meaning awaiting review: Transparency changes the presentation of `ligand`; no scientific meaning is inferred.
- colored `(ligand) and elem C` (command=color) - Target `(ligand) and elem C` is colored `ligand_carbon`. Suggested meaning awaiting review: Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- colored `(ligand) and elem O` (command=color) - Target `(ligand) and elem O` is colored `oxygen_red`. Suggested meaning awaiting review: Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- colored `(ligand) and elem N` (command=color) - Target `(ligand) and elem N` is colored `nitrogen_blue`. Suggested meaning awaiting review: Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- colored `(ligand) and elem S` (command=color) - Target `(ligand) and elem S` is colored `sulfur_yellow`. Suggested meaning awaiting review: Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- colored `(ligand) and elem CL` (command=color) - Target `(ligand) and elem CL` is colored `chlorine_green`. Suggested meaning awaiting review: Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- displayed `selected_waters` (command=show)
- configured `selected_waters` (command=set, value=0.15)
- colored `selected_waters` (command=color) - Target `selected_waters` is colored `water_blue`. Suggested meaning awaiting review: Color visually distinguishes `selected_waters`; no scientific meaning is inferred.
- configured `selected_waters` (command=set, value=0.64)
- transparency_changed `selected_waters` (command=set, value=0.64) - Target `selected_waters` has transparency `0.64`. Suggested meaning awaiting review: Transparency changes the presentation of `selected_waters`; no scientific meaning is inferred.
- displayed `retained_waters` (command=show)
- configured `retained_waters` (command=set, value=0.29)
- colored `retained_waters` (command=color) - Target `retained_waters` is colored `retained_green`. Suggested meaning awaiting review: Color visually distinguishes `retained_waters`; no scientific meaning is inferred.
- configured `retained_waters` (command=set, value=0.08)
- transparency_changed `retained_waters` (command=set, value=0.08) - Target `retained_waters` has transparency `0.08`. Suggested meaning awaiting review: Transparency changes the presentation of `retained_waters`; no scientific meaning is inferred.
- camera_oriented `ligand or pocket` (command=orient)
- camera_turned `scene` (command=turn)
- camera_turned `scene` (command=turn)
- camera_zoomed `ligand or pocket` (command=zoom)
- clipped `scene` (command=clip)
- ray_traced `scene` (command=ray)
- output_intent `renders/case01_real_a1_all_waters.png` (command=png)
- output_intent `renders/case01_real_a1_all_waters.pse` (command=save)
- session_terminated `session` (command=quit)
### scene:13ea6e979f88

Recorded view or figure settings: Open case01_real_a2_retained_waters.pse. The script orients ligand or pocket, turns y by -15 and x by 8, zooms by 4.8 and clips a slab of 35.

Automatically observed native scene operations:
- reinitialized `scene` (command=reinitialize)
- background_colored `scene` (command=bg_color) - Scene background is colored `white`. Suggested meaning awaiting review: Color visually distinguishes `scene`; no scientific meaning is inferred.
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=20)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=0)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=0.20)
- configured `global` (command=set, value=0.80)
- configured `global` (command=set, value=0.08)
- configured `global` (command=set, value=12)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=2)
- configured `global` (command=set, value=14)
- configured `global` (command=set, value=8)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.46)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=10)
- configured `global` (command=set, value=24)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.045)
- configured `global` (command=set, value=0.14)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=2.0)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=0.16)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=18)
- custom_color_defined `retained_green` (command=set_color) - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `removed_gray` (command=set_color) - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `warning_orange` (command=set_color) - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `provenance_blue` (command=set_color) - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_gray` (command=set_color) - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `pocket_gray` (command=set_color) - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_surface_gray` (command=set_color) - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `ligand_carbon` (command=set_color) - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `water_blue` (command=set_color) - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `oxygen_red` (command=set_color) - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `nitrogen_blue` (command=set_color) - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `sulfur_yellow` (command=set_color) - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `chlorine_green` (command=set_color) - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- loaded `structure` (command=load)
- atoms_removed `not (polymer.protein or (resn ZPZ and chain A and resi 401) or resn HOH)` (command=remove)
- hidden `all` (command=hide)
- displayed `context` (command=show)
- simplified `context` (command=show)
- colored `context` (command=color) - Target `context` is colored `protein_gray`. Author confirmed: Light gray identifies the surrounding protein context.
- configured `context` (command=set, value=0.64)
- transparency_changed `context` (command=set, value=0.64) - Target `context` has transparency `0.64`. Suggested meaning awaiting review: Transparency changes the presentation of `context`; no scientific meaning is inferred.
- created `pocket_surface` (command=create)
- displayed `pocket_surface` (command=show)
- simplified `pocket_surface` (command=show)
- colored `pocket_surface` (command=color) - Target `pocket_surface` is colored `protein_surface_gray`. Author confirmed: Pale gray identifies the pocket surface.
- configured `pocket_surface` (command=set, value=0.50)
- transparency_changed `pocket_surface` (command=set, value=0.50) - Target `pocket_surface` has transparency `0.50`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred.
- configured `pocket_surface` (command=set, value=1)
- displayed `pocket` (command=show)
- hidden `pocket and elem H` (command=hide)
- colored `pocket and elem C` (command=color) - Target `pocket and elem C` is colored `pocket_gray`. Author confirmed: Gray identifies carbon atoms in the pocket.
- configured `pocket` (command=set, value=0.085)
- configured `pocket` (command=set, value=0.34)
- transparency_changed `pocket` (command=set, value=0.34) - Target `pocket` has transparency `0.34`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket`; no scientific meaning is inferred.
- displayed `ligand` (command=show)
- configured `ligand` (command=set, value=0.25)
- configured `ligand` (command=set, value=0.0)
- transparency_changed `ligand` (command=set, value=0.0) - Target `ligand` has transparency `0.0`. Suggested meaning awaiting review: Transparency changes the presentation of `ligand`; no scientific meaning is inferred.
- colored `(ligand) and elem C` (command=color) - Target `(ligand) and elem C` is colored `ligand_carbon`. Author confirmed: Teal identifies ligand carbon atoms.
- colored `(ligand) and elem O` (command=color) - Target `(ligand) and elem O` is colored `oxygen_red`. Author confirmed: Red identifies ligand oxygen atoms.
- colored `(ligand) and elem N` (command=color) - Target `(ligand) and elem N` is colored `nitrogen_blue`. Author confirmed: Blue identifies ligand nitrogen atoms.
- colored `(ligand) and elem S` (command=color) - Target `(ligand) and elem S` is colored `sulfur_yellow`. Author confirmed: Yellow identifies ligand sulfur atoms.
- colored `(ligand) and elem CL` (command=color) - Target `(ligand) and elem CL` is colored `chlorine_green`. Author confirmed: Green identifies ligand chlorine atoms.
- displayed `retained_waters` (command=show)
- configured `retained_waters` (command=set, value=0.32)
- colored `retained_waters` (command=color) - Target `retained_waters` is colored `retained_green`. Author confirmed: Green identifies retained water molecules. Larger green spheres mark the six bridge proxies.
- configured `retained_waters` (command=set, value=0.04)
- transparency_changed `retained_waters` (command=set, value=0.04) - Target `retained_waters` has transparency `0.04`. Suggested meaning awaiting review: Transparency changes the presentation of `retained_waters`; no scientific meaning is inferred.
- displayed `bridge_waters` (command=show)
- configured `bridge_waters` (command=set, value=0.40)
- configured `bridge_waters` (command=set, value=0.00)
- transparency_changed `bridge_waters` (command=set, value=0.00) - Target `bridge_waters` has transparency `0.00`. Suggested meaning awaiting review: Transparency changes the presentation of `bridge_waters`; no scientific meaning is inferred.
- measurement_intent `bridge_proxy_p1` (command=distance)
- measurement_intent `bridge_proxy_l1` (command=distance)
- measurement_intent `bridge_proxy_p2` (command=distance)
- measurement_intent `bridge_proxy_l2` (command=distance)
- measurement_intent `bridge_proxy_p3` (command=distance)
- measurement_intent `bridge_proxy_l3` (command=distance)
- measurement_intent `bridge_proxy_p4` (command=distance)
- measurement_intent `bridge_proxy_l4` (command=distance)
- colored `bridge_proxy_*` (command=color) - Target `bridge_proxy_*` is colored `retained_green`. Author confirmed: Green distance guides connect the displayed protein-water-ligand bridge proxies.
- hidden `bridge_proxy_*` (command=hide)
- camera_oriented `ligand or pocket` (command=orient)
- camera_turned `scene` (command=turn)
- camera_turned `scene` (command=turn)
- camera_zoomed `ligand or pocket` (command=zoom)
- clipped `scene` (command=clip)
- ray_traced `scene` (command=ray)
- output_intent `renders/case01_real_a2_retained_waters.png` (command=png)
- output_intent `renders/case01_real_a2_retained_waters.pse` (command=save)
- session_terminated `session` (command=quit)
### scene:f36b50f390a9

Automatically observed native scene operations:
- reinitialized `scene` (command=reinitialize)
- background_colored `scene` (command=bg_color) - Scene background is colored `white`. Suggested meaning awaiting review: Color visually distinguishes `scene`; no scientific meaning is inferred.
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=20)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=0)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=off)
- configured `global` (command=set, value=0.20)
- configured `global` (command=set, value=0.80)
- configured `global` (command=set, value=0.08)
- configured `global` (command=set, value=12)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=2)
- configured `global` (command=set, value=14)
- configured `global` (command=set, value=8)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.46)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=10)
- configured `global` (command=set, value=24)
- configured `global` (command=set, value=3)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=0.045)
- configured `global` (command=set, value=0.14)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=2.0)
- configured `global` (command=set, value=0.28)
- configured `global` (command=set, value=0.16)
- configured `global` (command=set, value=on)
- configured `global` (command=set, value=18)
- custom_color_defined `retained_green` (command=set_color) - Custom color `retained_green` is defined as `[0.000, 0.620, 0.451]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `removed_gray` (command=set_color) - Custom color `removed_gray` is defined as `[0.557, 0.596, 0.659]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `warning_orange` (command=set_color) - Custom color `warning_orange` is defined as `[0.835, 0.369, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `provenance_blue` (command=set_color) - Custom color `provenance_blue` is defined as `[0.000, 0.447, 0.698]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_gray` (command=set_color) - Custom color `protein_gray` is defined as `[0.835, 0.878, 0.894]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `pocket_gray` (command=set_color) - Custom color `pocket_gray` is defined as `[0.325, 0.416, 0.447]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `protein_surface_gray` (command=set_color) - Custom color `protein_surface_gray` is defined as `[0.757, 0.816, 0.839]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `ligand_carbon` (command=set_color) - Custom color `ligand_carbon` is defined as `[0.090, 0.302, 0.329]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `water_blue` (command=set_color) - Custom color `water_blue` is defined as `[0.337, 0.706, 0.914]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `oxygen_red` (command=set_color) - Custom color `oxygen_red` is defined as `[0.698, 0.227, 0.180]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `nitrogen_blue` (command=set_color) - Custom color `nitrogen_blue` is defined as `[0.275, 0.361, 0.612]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `sulfur_yellow` (command=set_color) - Custom color `sulfur_yellow` is defined as `[0.769, 0.573, 0.000]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- custom_color_defined `chlorine_green` (command=set_color) - Custom color `chlorine_green` is defined as `[0.176, 0.498, 0.369]`. Suggested meaning awaiting review: A reusable color value is defined; no scientific meaning is inferred from the definition alone.
- loaded `structure` (command=load)
- atoms_removed `not (polymer.protein or (resn ZPZ and chain A and resi 401) or resn HOH)` (command=remove)
- hidden `all` (command=hide)
- displayed `context` (command=show)
- simplified `context` (command=show)
- colored `context` (command=color) - Target `context` is colored `protein_gray`. Suggested meaning awaiting review: Color visually distinguishes `context`; no scientific meaning is inferred.
- configured `context` (command=set, value=0.64)
- transparency_changed `context` (command=set, value=0.64) - Target `context` has transparency `0.64`. Suggested meaning awaiting review: Transparency changes the presentation of `context`; no scientific meaning is inferred.
- created `pocket_surface` (command=create)
- displayed `pocket_surface` (command=show)
- simplified `pocket_surface` (command=show)
- colored `pocket_surface` (command=color) - Target `pocket_surface` is colored `protein_surface_gray`. Suggested meaning awaiting review: Color visually distinguishes `pocket_surface`; no scientific meaning is inferred.
- configured `pocket_surface` (command=set, value=0.50)
- transparency_changed `pocket_surface` (command=set, value=0.50) - Target `pocket_surface` has transparency `0.50`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket_surface`; no scientific meaning is inferred.
- configured `pocket_surface` (command=set, value=1)
- displayed `pocket` (command=show)
- hidden `pocket and elem H` (command=hide)
- colored `pocket and elem C` (command=color) - Target `pocket and elem C` is colored `pocket_gray`. Suggested meaning awaiting review: Color visually distinguishes `pocket and elem C`; no scientific meaning is inferred.
- configured `pocket` (command=set, value=0.085)
- configured `pocket` (command=set, value=0.34)
- transparency_changed `pocket` (command=set, value=0.34) - Target `pocket` has transparency `0.34`. Suggested meaning awaiting review: Transparency changes the presentation of `pocket`; no scientific meaning is inferred.
- displayed `ligand` (command=show)
- configured `ligand` (command=set, value=0.25)
- configured `ligand` (command=set, value=0.0)
- transparency_changed `ligand` (command=set, value=0.0) - Target `ligand` has transparency `0.0`. Suggested meaning awaiting review: Transparency changes the presentation of `ligand`; no scientific meaning is inferred.
- colored `(ligand) and elem C` (command=color) - Target `(ligand) and elem C` is colored `ligand_carbon`. Suggested meaning awaiting review: Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- colored `(ligand) and elem O` (command=color) - Target `(ligand) and elem O` is colored `oxygen_red`. Suggested meaning awaiting review: Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- colored `(ligand) and elem N` (command=color) - Target `(ligand) and elem N` is colored `nitrogen_blue`. Suggested meaning awaiting review: Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- colored `(ligand) and elem S` (command=color) - Target `(ligand) and elem S` is colored `sulfur_yellow`. Suggested meaning awaiting review: Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- colored `(ligand) and elem CL` (command=color) - Target `(ligand) and elem CL` is colored `chlorine_green`. Suggested meaning awaiting review: Color may highlight the ligand or ligand selection; confirm if it carries the panel message.
- hidden `resn HOH` (command=hide)
- camera_oriented `ligand or pocket` (command=orient)
- camera_turned `scene` (command=turn)
- camera_turned `scene` (command=turn)
- camera_zoomed `ligand or pocket` (command=zoom)
- clipped `scene` (command=clip)
- ray_traced `scene` (command=ray)
- output_intent `renders/case01_real_a3_waters_removed.png` (command=png)
- output_intent `renders/case01_real_a3_waters_removed.pse` (command=save)
- session_terminated `session` (command=quit)

</details>

## Molecules and selections

Recorded molecules: 0; selections: 21. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.
Open **Selected regions** in the GUI to inspect the recorded selections and their source commands.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 0
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Package checks passed for `draft` mode.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; CC0-1.0 for RCSB PDB coordinate data. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
