# Figure 4E — Trace interaction state changes

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 4E
- Claim: The 18 displayed 5-HT1B-ergotamine interaction rows contain 2,299 state changes.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/case05a_publication_prolif_event_map.png`
- Evidence summary: Review the supplied event matrix and formed/lost transition table.: The 18 displayed rows contain 1,148 formations and 1,151 losses across 500 recorded time points: 2,299 state changes.
- Visual meanings: to record
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Review the supplied event matrix and formed/lost transition table.: The 18 displayed rows contain 1,148 formations and 1,151 losses across 500 recorded time points: 2,299 state changes.

## Visual meanings

Visual meanings: awaiting author description.

## Open items and limits

- Recommended: Original topology and trajectory files are needed for trajectory reproduction.
- Additional review items: 1; see `human_review_required` in `validation_report.json`.
- Scope: Reproduce static figures using their analysis sources and recorded plotting or assembly settings.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: to record / 1 present
- Structure/map files: to record
- Evidence entries: 1 recorded
- Dedicated evidence/validation files: 3 present
- `Figure 4E`: The 18 displayed 5-HT1B-ergotamine interaction rows contain 2,299 state changes.
  Renders: `renders/case05a_publication_prolif_event_map.png` (Rendered panel)
  Supporting files: `data/case05_real_prolif_event_matrix.csv` (Evidence note), `data/case05_real_prolif_event_transitions.csv` (Evidence note), `data/ifp_df.pkl` (Evidence note)

## Claims

### Figure 4E

- Text: The 18 displayed 5-HT1B-ergotamine interaction rows contain 2,299 state changes.
- Type: trajectory_mechanism
- Figure/panel: Figure 4E
- Linked scenes: 1
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- trajectory analysis
  Claim link: claim:gui:d28cd42eb228
  How it was checked: Review the supplied event matrix and formed/lost transition table.
  Source files: `data/case05_real_prolif_event_matrix.csv` (Evidence note), `data/case05_real_prolif_event_transitions.csv` (Evidence note), `data/ifp_df.pkl` (Evidence note)
  Observation: The 18 displayed rows contain 1,148 formations and 1,151 losses across 500 recorded time points: 2,299 state changes.
  Analysis settings: System: 5-HT1B-ergotamine. Display: 18 selected switching interactions over 0-499 ns at 1 ns intervals. Original supplied fingerprint dataset: 50 interactions from one recorded series.

## Uncertainty

- general: The view selects 18 switching interactions. The full fingerprint dataset contains 50 interactions, including four persistent interactions. Regenerating fingerprints requires the original topology and trajectory.
## Scene files and images

- Rendered panel: `renders/case05a_publication_prolif_event_map.png`

## Reproduce the figure

Review the linked analysis sources and recorded figure settings. Use the original analysis or figure-assembly tools to reproduce these static figures.
- Figure settings (`scene:c9367de6e3b0`): Interaction-state map: 18 rows across 0–499 ns; green = present (1), pale = absent (0). Lower bars show formations above zero and losses below zero.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Imported scene observations: 0.

## Scene details

### scene:c9367de6e3b0

Recorded view or figure settings: Interaction-state map: 18 rows across 0–499 ns; green = present (1), pale = absent (0). Lower bars show formations above zero and losses below zero.
Scene operations and visual meanings: to record.

</details>

## Molecules and selections

Recorded molecules: 0; selections: 0. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 1
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Required checks passed for `draft`.

Recommended:
- `CLAIM.TRAJECTORY.REQUIRED_CONTEXT`: Original topology and trajectory files are needed for trajectory reproduction.
  Edit: `/claims/0/evidence_ids`
  Next: Attach the original inputs and link them to the analysis evidence. Preserve the recorded method and sampling settings.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; Apache-2.0 for ProLIF-paper fingerprint data. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
