# Figure 1B4 - AP5 conformational clusters

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 1B4
- Claim: Thirty AP5 instances form four descriptive conformational clusters.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/4_1_ap5_conformational_landscape.png`, `renders/4_2_ap5_representative_states.png`
- Evidence summary: Review the supplied protein-aligned AP5 coordinates, standardized-coordinate PCA, clustering and density summaries.: The supplied assignments retain 30 AP5 instances from 15 of 16 input PDB entries and identify four clusters. PC1 and PC2 explain 32.66% and 14.19% of the variance.
- Visual meanings: to record
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Review the supplied protein-aligned AP5 coordinates, standardized-coordinate PCA, clustering and density summaries.: The supplied assignments retain 30 AP5 instances from 15 of 16 input PDB entries and identify four clusters. PC1 and PC2 explain 32.66% and 14.19% of the variance.

## Visual meanings

Visual meanings: awaiting author description.

## Open items and limits

- Required checks passed for `draft` export
- Additional review items: 1; see `human_review_required` in `validation_report.json`.
- Scope: Reproduce static figures using their analysis sources and recorded plotting or assembly settings.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: to record / 2 present
- Structure/map files: 16 present
- Evidence entries: 1 recorded
- Dedicated evidence/validation files: 5 present
- `Figure 1B4`: Thirty AP5 instances form four descriptive conformational clusters.
  Renders: `renders/4_1_ap5_conformational_landscape.png` (Rendered panel), `renders/4_2_ap5_representative_states.png` (Rendered panel)
  Supporting files: `data/4_1_ap5_conformational_landscape.csv` (Validation report), `data/B4_PROVENANCE.json` (Validation report), `data/ap5_instance_assignments.csv` (Validation report), `data/ap5_pca_explained_variance.csv` (Validation report), `data/ap5_representative_states.csv` (Validation report), `data/structures/pdb_00001ake.cif.gz` (Structure file), `data/structures/pdb_00001e4v.cif.gz` (Structure file), `data/structures/pdb_00001e4y.cif.gz` (Structure file), `data/structures/pdb_00003hpq.cif.gz` (Structure file), `data/structures/pdb_00003hpr.cif.gz` (Structure file), `data/structures/pdb_00004x8l.cif.gz` (Structure file), `data/structures/pdb_00004x8o.cif.gz` (Structure file), `data/structures/pdb_00005eje.cif.gz` (Structure file), `data/structures/pdb_00006ham.cif.gz` (Structure file), `data/structures/pdb_00006hap.cif.gz` (Structure file), `data/structures/pdb_00008bqf.cif.gz` (Structure file), `data/structures/pdb_00008pvw.cif.gz` (Structure file), `data/structures/pdb_00008q2b.cif.gz` (Structure file), `data/structures/pdb_00009l14.cif.gz` (Structure file), `data/structures/pdb_00009r6u.cif.gz` (Structure file), `data/structures/pdb_00009r71.cif.gz` (Structure file)

## Claims

### Figure 1B4

- Text: Thirty AP5 instances form four descriptive conformational clusters.
- Type: model_comparison
- Figure/panel: Figure 1B4
- Linked scenes: 1
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- external validation
  Claim link: claim:gui:c8413a7ada2a
  How it was checked: Review the supplied protein-aligned AP5 coordinates, standardized-coordinate PCA, clustering and density summaries.
  Source files: `data/4_1_ap5_conformational_landscape.csv` (Validation report), `data/B4_PROVENANCE.json` (Validation report), `data/ap5_instance_assignments.csv` (Validation report), `data/ap5_pca_explained_variance.csv` (Validation report), `data/ap5_representative_states.csv` (Validation report), `data/structures/pdb_00001ake.cif.gz` (Structure file), `data/structures/pdb_00001e4v.cif.gz` (Structure file), `data/structures/pdb_00001e4y.cif.gz` (Structure file), `data/structures/pdb_00003hpq.cif.gz` (Structure file), `data/structures/pdb_00003hpr.cif.gz` (Structure file), `data/structures/pdb_00004x8l.cif.gz` (Structure file), `data/structures/pdb_00004x8o.cif.gz` (Structure file), `data/structures/pdb_00005eje.cif.gz` (Structure file), `data/structures/pdb_00006ham.cif.gz` (Structure file), `data/structures/pdb_00006hap.cif.gz` (Structure file), `data/structures/pdb_00008bqf.cif.gz` (Structure file), `data/structures/pdb_00008pvw.cif.gz` (Structure file), `data/structures/pdb_00008q2b.cif.gz` (Structure file), `data/structures/pdb_00009l14.cif.gz` (Structure file), `data/structures/pdb_00009r6u.cif.gz` (Structure file), `data/structures/pdb_00009r71.cif.gz` (Structure file)
  Observation: The supplied assignments retain 30 AP5 instances from 15 of 16 input PDB entries and identify four clusters. PC1 and PC2 explain 32.66% and 14.19% of the variance.
  Analysis settings: Alignment: corresponding protein C-alpha atoms to 1AKE chain A. Features: 55 AP5 heavy atoms after applying that protein alignment; standardized coordinates. Clustering: KMeans on PC1 and PC2, four clusters, random state 19, n_init 50. Excluded instances: 8PVW A and 9R6U A. Representatives: 4X8O B, 5EJE B, 6HAM A and 8Q2B A.

## Uncertainty

- general: The landscape is an exploratory density transform of a crystallographic sample. Its energy-like scale depends on the selected structures, alignment, KDE and chosen display temperature; thermodynamic interpretation requires equilibrium sampling.
## Scene files and images

- Rendered panel: `renders/4_1_ap5_conformational_landscape.png`
- Rendered panel: `renders/4_2_ap5_representative_states.png`

## Reproduce the figure

Review the linked analysis sources and recorded figure settings. Use the original analysis or figure-assembly tools to reproduce these static figures.
- Figure settings (`scene:eb892fd4391b`): PC1 versus PC2 for 30 AP5 instances with four cluster assignments. The saved surface applies -kB*T*ln(P/Pmax) to a KDE of these crystallographic samples at a chosen 300 K display temperature. Representatives: 4X8O B, 5EJE B, 6HAM A and 8Q2B A.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Imported scene observations: 0.

## Scene details

### scene:eb892fd4391b

Recorded view or figure settings: PC1 versus PC2 for 30 AP5 instances with four cluster assignments. The saved surface applies -kB*T*ln(P/Pmax) to a KDE of these crystallographic samples at a chosen 300 K display temperature. Representatives: 4X8O B, 5EJE B, 6HAM A and 8Q2B A.
Scene operations and visual meanings: to record.

</details>

## Molecules and selections

Recorded molecules: 0; selections: 0. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 0
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Package checks passed for `draft` mode.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; CC0-1.0 for RCSB PDB coordinate data. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
