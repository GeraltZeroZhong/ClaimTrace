# Replay source for this panel. Run from the package root.
load data/pdb_ap5/pdb_00001ake.cif.gz, source
create protein, source and polymer.protein and chain A
create ligand, source and resn AP5 and chain A
delete source
remove hydro
set_view (-0.00452045, 0.34387499, -0.93900460, 0.96000928, 0.26435494, 0.09218842, 0.27993178, -0.90103632, -0.33131820, 0.00000000, 0.00000000, -142.61358643, 21.58662415, 44.55500793, 20.07944107, 112.43763733, 172.78953552, 20.00000000)
