# Run from this directory to restore the supplied native session.
reinitialize
load native/6_1_interaction_view_alternate.pse
