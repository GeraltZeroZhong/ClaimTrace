# Figure 1B6 - Alternate AP5 view

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 1B6
- Claim: An alternate camera presents the same AP5 interaction scene.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/6_1_interaction_view_alternate.png`
- Evidence summary: Inspect the supplied alternate view, camera record and native session reference.: The supplied alternate view retains AP5 and its pocket context. The scene script records the camera, and the replay script points to the supplied native PSE.
- Visual meanings: to record
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Inspect the supplied alternate view, camera record and native session reference.: The supplied alternate view retains AP5 and its pocket context. The scene script records the camera, and the replay script points to the supplied native PSE.

## Visual meanings

Visual meanings: awaiting author description.

## Open items and limits

- Required checks passed for `draft` export
- Additional review items: 5; see `human_review_required` in `validation_report.json`.
- Scope: Imported scene instructions preserve visual context. Viewer loading, selections, and rendered output require a replay check.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: 3 present / 1 present
- Structure/map files: 1 present
- Evidence entries: 1 recorded
- Dedicated evidence/validation files: to record
- `Figure 1B6`: An alternate camera presents the same AP5 interaction scene.
  Renders: `renders/6_1_interaction_view_alternate.png` (Rendered panel)
  Native files: `native/6_1_interaction_view_alternate.pml` (PyMOL scene)
  Supporting files: `native/6_1_interaction_view_alternate.pml` (PyMOL scene), `native/replay-6_1_interaction_view_alternate.pml` (PyMOL scene), `renders/6_1_interaction_view_alternate.png` (Rendered panel), `native/native/6_1_interaction_view_alternate.pse` (PyMOL session), `native/data/pdb_ap5/pdb_00001ake.cif.gz` (Structure file)

## Claims

### Figure 1B6

- Text: An alternate camera presents the same AP5 interaction scene.
- Type: simple_structure_view
- Figure/panel: Figure 1B6
- Linked scenes: 1
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- manual rationale
  Claim link: claim:gui:484399b47d66
  How it was checked: Inspect the supplied alternate view, camera record and native session reference.
  Source files: `native/6_1_interaction_view_alternate.pml` (PyMOL scene), `native/replay-6_1_interaction_view_alternate.pml` (PyMOL scene), `renders/6_1_interaction_view_alternate.png` (Rendered panel), `native/native/6_1_interaction_view_alternate.pse` (PyMOL session), `native/data/pdb_ap5/pdb_00001ake.cif.gz` (Structure file)
  Observation: The supplied alternate view retains AP5 and its pocket context. The scene script records the camera, and the replay script points to the supplied native PSE.
  Analysis settings: Structure: 1AKE chain A; ligand: AP5; distance-guide cutoff: 4 angstrom. Replay target: native/6_1_interaction_view_alternate.pse in the completed package.

## Uncertainty

- general: The GUI records the supplied files and camera. Open the PSE in PyMOL to check objects, selections, representations and camera together. Interpret the distance guides as proximity.
## Scene files and images

- PyMOL scene: `native/6_1_interaction_view_alternate.pml`
- PyMOL scene: `native/replay-6_1_interaction_view_alternate.pml`
- Rendered panel: `renders/6_1_interaction_view_alternate.png`
- PyMOL session: `native/native/6_1_interaction_view_alternate.pse`

## Reproduce the figure

ClaimTrace imports saved scene instructions. Open the scene in its original viewer to check loading, selections, and the saved view. Assess the scientific claim using the linked evidence and limitations.
Replay only native scripts you trust. Review raw or unknown commands first, and use an isolated, network-restricted viewer when provenance is uncertain.
- PyMOL scene: `native/6_1_interaction_view_alternate.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol 6_1_interaction_view_alternate.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\6_1_interaction_view_alternate.pml'`
- PyMOL scene: `native/replay-6_1_interaction_view_alternate.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol replay-6_1_interaction_view_alternate.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\replay-6_1_interaction_view_alternate.pml'`
- PyMOL session: open `native/native/6_1_interaction_view_alternate.pse` in a compatible local PyMOL version.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Observed scene operations:
- `op:pymol:a71b6d9a3068`: loaded `source`
- `op:pymol:5b564e3525b1`: created `protein`
- `op:pymol:09a374a6c121`: created `ligand`
- `op:pymol:d82bb7782ae8`: object_deleted `source`
- `op:pymol:c3026a57de77`: atoms_removed `hydro`
- `op:pymol:2ecadbb23b77`: camera_set `scene`
- `op:pymol:ba1cc6e70e76`: reinitialized `scene`
- `op:pymol:b2eaa507bcc3`: loaded `6_1_interaction_view_alternate`

Native references needing or containing identity context:
- `native-ref:pymol:a40b7f019d25`: `source` -> data/pdb_ap5/pdb_00001ake.cif.gz
- `native-ref:pymol:b3df65bc3b98`: `6_1_interaction_view_alternate` -> native/6_1_interaction_view_alternate.pse

Native resource references:
- `resource:pymol:5ff72ec1799b` (relative, fixity available): `data/pdb_ap5/pdb_00001ake.cif.gz`
- `resource:pymol:9ce579d391fb` (relative, fixity available): `native/6_1_interaction_view_alternate.pse`

## Scene details

### scene:bb90dbf36729

Automatically observed native scene operations:
- loaded `source` (command=load)
- created `protein` (command=create)
- created `ligand` (command=create)
- object_deleted `source` (command=delete)
- atoms_removed `hydro` (command=remove)
- camera_set `scene` (command=set_view)
### scene:da35fd1f57ac

Automatically observed native scene operations:
- reinitialized `scene` (command=reinitialize)
- loaded `6_1_interaction_view_alternate` (command=load)

</details>

## Molecules and selections

Recorded molecules: 0; selections: 0. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 0
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Package checks passed for `draft` mode.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; CC0-1.0 for RCSB PDB coordinate data. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
