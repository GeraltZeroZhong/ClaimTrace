# Sources

## Experimental complex

The static interaction, pocket, surface and contact-map panels use RCSB PDB `1AKE`, chain A and its bound `AP5` ligand. The coordinate file is retained as `data/pdb_ap5/pdb_00001ake.cif.gz`.

## AlphaFold model

- UniProt: `P69441` (`KAD_ECOLI`), 214 residues.
- AlphaFold DB entry: `AF-P69441-F1`, model v6.
- Global pLDDT: 95.94.
- Residue-level range in the downloaded coordinates: 87.88–98.62.
- AFDB metadata reports 97.7% of residues above pLDDT 90.

## Ap5A structural ensemble

The RCSB search required both:

- polymer reference accession exactly equal to UniProt `P69441`; and
- chemical component ID exactly equal to `AP5`.

The 16 returned entries were `1AKE`, `1E4V`, `1E4Y`, `3HPQ`, `3HPR`, `4X8L`, `4X8O`, `5EJE`, `6HAM`, `6HAP`, `8BQF`, `8PVW`, `8Q2B`, `9L14`, `9R6U` and `9R71`. Coordinates are stored under `data/pdb_ap5/`.

This is a crystallographic structural ensemble and is not described as an MD trajectory.

