# Replay source for this panel. Run from the package root.
load data/pdb_ap5/pdb_00001ake.cif.gz, source
create protein, source and polymer.protein and chain A
create ligand, source and resn AP5 and chain A
delete source
remove hydro
set_view (0.18148082, 0.71096420, 0.67940748, -0.68562150, -0.40380037, 0.60569650, 0.70497358, -0.57573873, 0.41417038, 0.00000000, 0.00000000, -154.81491089, 24.06376457, 45.73715973, 24.59595680, 122.05725098, 187.57257080, 20.00000000)
