# Figure 1B5 - Local to global context

Trace each figure statement to its visual evidence, source files, settings and limitations.

## Review summary

- Figure/panel: Figure 1B5
- Claim: The overall adenylate kinase view places AP5 between the highlighted domains.
- Readiness: ready for `draft` handoff
- Rendered panel: `renders/5_1_overall_structure.png`
- Evidence summary: Inspect the supplied overall view, saved session and 1AKE structure.: The saved 1AKE view shows chain A with AP5 and highlighted residue ranges 30-59 and 122-159. The overall view places AP5 between these domains.
- Visual meanings: to record
- Selected export checks: passed; additional review items in `human_review_required` in `validation_report.json`

## How to read this package

Extract the ZIP, open a terminal in the extracted package folder, and run:

```bash
claimtrace gui .
```

Select a claim and open **Review** to inspect its figure, source files, evidence, and limitations. **Prepare** shows the details to complete.

In the terminal, run `claimtrace review .` to read the audit or `claimtrace prepare .` to continue editing.

- Open rendered panels in `renders/`, then read the claim, evidence and visual meanings below.
- Review **Open items and limits** for required updates and recommendations.
- Author-confirmed meanings and tool suggestions carry separate labels below.
- Use `checksums/sha256.txt` to verify included files.
- Native viewer files are under `native/`; files referenced by relative native paths may be co-located there for replay, while other data are under `data/`.
- `semantic_layer.json` is the canonical machine-readable record for advanced review.

## Evidence summary

- Inspect the supplied overall view, saved session and 1AKE structure.: The saved 1AKE view shows chain A with AP5 and highlighted residue ranges 30-59 and 122-159. The overall view places AP5 between these domains.

## Visual meanings

Visual meanings: awaiting author description.

## Open items and limits

- Required checks passed for `draft` export
- Additional review items: 3; see `human_review_required` in `validation_report.json`.
- Scope: Imported scene instructions preserve visual context. Viewer loading, selections, and rendered output require a replay check.
- Evidence: Assess claim support from linked source files and author-reviewed observations.

## At a glance

- Validation status: `pass`
- Validation scope: package completeness, traceability, paths and fixity.
- Native/render files: 2 present / 1 present
- Structure/map files: 1 present
- Evidence entries: 1 recorded
- Dedicated evidence/validation files: 1 present
- `Figure 1B5`: The overall adenylate kinase view places AP5 between the highlighted domains.
  Renders: `renders/5_1_overall_structure.png` (Rendered panel)
  Native files: `native/5_1_overall_structure.pml` (PyMOL scene)
  Supporting files: `native/5_1_overall_structure.pml` (PyMOL scene), `native/5_1_overall_structure.pse` (PyMOL session), `data/SOURCES.md` (Evidence note), `native/data/pdb_ap5/pdb_00001ake.cif.gz` (Structure file)

## Claims

### Figure 1B5

- Text: The overall adenylate kinase view places AP5 between the highlighted domains.
- Type: simple_structure_view
- Figure/panel: Figure 1B5
- Linked scenes: 1
- Linked evidence entries: 1
- Caveats/uncertainty notes: 1


## Evidence

- manual rationale
  Claim link: claim:gui:d17e04c95970
  How it was checked: Inspect the supplied overall view, saved session and 1AKE structure.
  Source files: `native/5_1_overall_structure.pml` (PyMOL scene), `native/5_1_overall_structure.pse` (PyMOL session), `data/SOURCES.md` (Evidence note), `native/data/pdb_ap5/pdb_00001ake.cif.gz` (Structure file)
  Observation: The saved 1AKE view shows chain A with AP5 and highlighted residue ranges 30-59 and 122-159. The overall view places AP5 between these domains.
  Analysis settings: Structure: PDB 1AKE, chain A. Blue residues: 30-59. Green residues: 122-159. View: saved overall structure.

## Uncertainty

- general: This crystal structure supplies static spatial context. The original PSE preserves the highlighted view; record the residue ranges alongside the reduced PML. Native-view replay remains pending.
## Scene files and images

- PyMOL scene: `native/5_1_overall_structure.pml`
- Rendered panel: `renders/5_1_overall_structure.png`
- PyMOL session: `native/5_1_overall_structure.pse`

## Reproduce the figure

ClaimTrace imports saved scene instructions. Open the scene in its original viewer to check loading, selections, and the saved view. Assess the scientific claim using the linked evidence and limitations.
Replay only native scripts you trust. Review raw or unknown commands first, and use an isolated, network-restricted viewer when provenance is uncertain.
- PyMOL scene: `native/5_1_overall_structure.pml`. Start PyMOL with `native` as the working directory so relative `load` paths resolve.
  - Bash: `cd native && pymol 5_1_overall_structure.pml`
  - PowerShell: `Set-Location 'native'; pymol '.\5_1_overall_structure.pml'`
- PyMOL session: open `native/5_1_overall_structure.pse` in a compatible local PyMOL version.

<details>
<summary>Scene records and imported commands</summary>

## Imported scene observations

Observed scene operations:
- `op:pymol:1bc1f8cff128`: loaded `source`
- `op:pymol:3446b348c939`: created `protein`
- `op:pymol:cac6f83def31`: created `ligand`
- `op:pymol:d500e65486af`: object_deleted `source`
- `op:pymol:aeadf44e3252`: atoms_removed `hydro`
- `op:pymol:588102aba998`: camera_set `scene`

Native references needing or containing identity context:
- `native-ref:pymol:8a691b543897`: `source` -> data/pdb_ap5/pdb_00001ake.cif.gz

Native resource references:
- `resource:pymol:65b1a3f30d93` (relative, fixity available): `data/pdb_ap5/pdb_00001ake.cif.gz`

## Scene details

### scene:e40be81abfd3

Automatically observed native scene operations:
- loaded `source` (command=load)
- created `protein` (command=create)
- created `ligand` (command=create)
- object_deleted `source` (command=delete)
- atoms_removed `hydro` (command=remove)
- camera_set `scene` (command=set_view)

</details>

## Molecules and selections

Recorded molecules: 0; selections: 0. The complete records are under `entities` and `selections` in `semantic_layer.json`.

Entries marked figure-central:

0 marked.

## Validation

- Overall status: `pass`
- Blocking updates: 0
- Recommended updates: 0
- Waiver records: 0
- Findings waived: 0
- Full machine-readable report: `validation_report.json`

Next actions:
- Package checks passed for `draft` mode.

## Checksums

Package checksums are in `checksums/sha256.txt`.

## Reuse

- License: MIT for ClaimTrace-authored tutorial materials under the repository LICENSE; CC0-1.0 for RCSB PDB coordinate data. See DATA_SOURCES.txt for component attribution and reuse terms.
- Citation: Zhong, Shuyu. ClaimTrace, version 1.0. https://github.com/GeraltZeroZhong/ClaimTrace. Cite the scientific sources listed in DATA_SOURCES.txt when reusing their data.
- Restrictions: Retain source attribution and applicable license notices as specified in DATA_SOURCES.txt.

See DATA_SOURCES.txt for file-level source attribution and reuse terms.
