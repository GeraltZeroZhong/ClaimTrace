# Replay source for this panel. Run from the package root.
load data/pdb_ap5/pdb_00001ake.cif.gz, source
create protein, source and polymer.protein and chain A
create ligand, source and resn AP5 and chain A
delete source
remove hydro
set_view (-0.71960998, 0.25307393, -0.64661819, 0.68171632, 0.43451196, -0.58861047, 0.13200139, -0.86438006, -0.48520380, 0.00000000, 0.00000000, -136.94230652, 21.58662415, 44.55500793, 20.07944107, 107.96636200, 165.91825867, 20.00000000)
