# Replay source for this panel. Run from the package root.
load data/pdb_ap5/pdb_00001ake.cif.gz, source
create protein, source and polymer.protein and chain A
create ligand, source and resn AP5 and chain A
delete source
remove hydro
set_view (0.99008143, 0.07314292, -0.11995402, 0.07983422, 0.40966576, 0.90873557, 0.11560863, -0.90929866, 0.39976317, 0.00000000, 0.00000000, -128.43537903, 21.58662415, 44.55500793, 20.07944107, 101.25942993, 155.61132812, 20.00000000)
