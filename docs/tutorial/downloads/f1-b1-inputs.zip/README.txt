ClaimTrace illustrated tutorial | Figure 1B1: Pocket visibility

1. Extract this ZIP.
2. Open ClaimTrace and choose Start with files (or Choose files).
3. Select all 7 files inside files/.
4. Follow the illustrated case page.

LAB_NOTES.txt provides the supplied observations. The files/ directory groups the scientific inputs for GUI import. source-map.json records relative resource locations for native scenes. Use the completed example package to replay scenes with their supporting files.

Data sources and attribution: see DATA_SOURCES.txt. Use the completed example package for native viewer replay.
